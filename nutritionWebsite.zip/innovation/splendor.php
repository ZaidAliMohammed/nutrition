<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="includes/js.js"></script>
<script src="includes/jquery-1.11.3.js"></script>
<link rel="stylesheet" type="text/css" href="includes/css.css">



<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<title>Splendor, healthy diet recipes</title>


<meta name="description" content="The noun splendor has its roots in the Latin word splendere, which means bright."/>





<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google-site-verification" content="_E9bflB0E_wGFcR1wGyHfzUjwkcBj1_OYTcchkUSKuU" />
<meta http-equiv="cache-control" content="no-cache,no-store,must-revalidate">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="classification" content="Innovation, innovation, healthy food, weight loss, web, website, nutrition, diet, diet recipes, splendor, nutrition recipes, food recipes, e-marketing, beirut, lebanon"/>
<meta name="category" content="nutrition website lebanon, healthy food website lebanon, nutrition recipes lebanon, diet food recipes lebanon, diet decipes lebanon,  beirut"/>
<meta name="subject" content="low cal Lebanon , nutrition Website, weight loss Lebanon, diet food Lebanon" />
<meta name="author" content="Browse Me, By Zaid Mohammed">
<meta name="robots" content="index,follow" />




<meta property="og:title" content="Article Title">
<meta property="og:type" content="article">
<meta property="og:url" content="http://www.eatingwell.com/recipes_menus/collections/healthy_diet_recipes">
<meta property="og:image" content="http://www.healthquestkansas.com/wp-content/uploads/2016/01/Diet.jpg">


<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@username">
<meta name="twitter:title" content="Cardamom Donut Bites with Orange-Honey Glaze">
<meta name="twitter:description" content="Small article description.">



<link rel="publisher" href="https://plus.google.com/example">




<h1></h1>



</head>



<body>
<div class="totalhome_splendor">
          <!------------------------------------------------THE HEADER CALLING---------------------------->
         <div> 
		 <?php include "includes/header.php"; ?>
		 </div>
		 <!------------------------------------------------THE LEFT SIDE---------------------------->
     <div class="bod_home_splendor">
		 <div class ="left_contact">
		    <!--------------------innovation---------------->
            <div class="ainn_home">
            <p><img src="icons/splendor.png" title="healthy diet recipes, weight loss" alt="logo, diet, healthy food recipes"><b class="m2">PLENDOR</b></p>
            </div>
			<!--------------------text--------------------->
			
			<?php
			include 'db/db.php';
		    $sql_splendor="select * from about where status='1' and title='2' order by id DESC";
		    $res_splendor=mysql_query($sql_splendor);
		    $result_splendor=mysql_fetch_array($res_splendor);
		    ?>
		 
		 
            <div class="text_home_left"> <?=$result_splendor['content']?> </div> 
			<!-----------------main video------------------------>
            <?php
		    include 'db/db.php';
		    $sql_splendor_video_main="select * from splendor_video where status='1' order by id asc limit 1";
		    $res_splendor_video_main=mysql_query($sql_splendor_video_main);
			$result_splendor_video_main=mysql_fetch_array($res_splendor_video_main);
		    ?>
			
		
			 <iframe width="675" height="444"
             src="<?=$result_splendor_video_main['link']?>" title="video for healthy food, diet recipes, weight loss, and more other videos!">   
             </iframe> 
			 
		
		<!------------------------------------------------THE RIGHT SIDE---------------------------->
		 <div class ="right_home">
		 
			 
			  
			  
			  
			<?php
		    include 'db/db.php';
					    $sql_splendor_video1="select * from splendor_video where status='1' and title='1' order by id";
		    $res_splendor_video1=mysql_query($sql_splendor_video1);
		    $result_splendor_video1=mysql_fetch_array($res_splendor_video1);
			
					    $sql_splendor_video2="select * from splendor_video where status='1' and title='2' order by id";
		    $res_splendor_video2=mysql_query($sql_splendor_video2);
		    $result_splendor_video2=mysql_fetch_array($res_splendor_video2);
			
					    $sql_splendor_video3="select * from splendor_video where status='1' and title='3' order by id";
		    $res_splendor_video3=mysql_query($sql_splendor_video3);
		    $result_splendor_video3=mysql_fetch_array($res_splendor_video3);
			
					    $sql_splendor_video4="select * from splendor_video where status='1' and title='4' order by id";
		    $res_splendor_video4=mysql_query($sql_splendor_video4);
		    $result_splendor_video4=mysql_fetch_array($res_splendor_video4);
			
			
			
			
			
			
            ?>
			
			 <!-------------------sec video 1-------------------->
			              <div class="calculation_splendor">
			  <div class="r1_splendor">
			  <iframe width="200" height="100"
              src="<?=$result_splendor_video1['link']?>" title="video for healthy food, diet recipes, weight loss, and more other videos!">
              </iframe> 
		      </div>
              </div>
			   <!-------------------sec video 2-------------------->
			  			  <div class="calculation_splendor">
			  <div class="r1_splendor">
			  <iframe width="200" height="100"
              src="<?=$result_splendor_video2['link']?>" title="video for healthy food, diet recipes, weight loss, and more other videos!">
              </iframe> 
		      </div>
              </div>
			   <!-------------------sec video 3-------------------->
			  			  <div class="calculation_splendor">
			  <div class="r1_splendor">
			  <iframe width="200" height="100"
              src="<?=$result_splendor_video3['link']?>" title="video for healthy food, diet recipes, weight loss, and more other videos!">
              </iframe> 
		      </div>
              </div>
			   <!-------------------sec video 4-------------------->
			  			  <div class="calculation_splendor">
			  <div class="r1_splendor">
			  <iframe width="200" height="100"
              src="<?=$result_splendor_video4['link']?>" title="video for healthy food, diet recipes, weight loss, and more other videos!">
              </iframe> 
		      </div>
              </div>
	

 
			  </div>
			  </div>
			  <div class="rhi_head">
		   	  </div>		
              </div>
			  
			  </div>
			  
	     </div>
<?php include "includes/footer.php"; ?>
</div>
</body>

</html>