<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script src="includes/js.js"></script>
<script src="includes/jquery-1.11.3.js"></script>
<script src="includes/bootstrap.min.css"></script>
<link rel="stylesheet" type="text/css" href="includes/css.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>



<title>Innovation, menu, hot deals, bmi calculator, unit conversion</title>
<?php include "includes/meta.php";?>
  
  


<meta property="og:title" content="Article Title">
<meta property="og:type" content="article">
<meta property="og:url" content="http://www.eatingwell.com/recipes_menus/collections/healthy_diet_recipes">
<meta property="og:image" content="http://www.healthquestkansas.com/wp-content/uploads/2016/01/Diet.jpg">


<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@username">
<meta name="twitter:title" content="Cardamom Donut Bites with Orange-Honey Glaze">
<meta name="twitter:description" content="Small article description.">



<link rel="publisher" href="https://plus.google.com/example">

<h1></h1>  
  
  
  
  
  
  

</head>



<body>



			  
			  
			  
<div class="totalhome">
          <!------------------------------------------------THE HEADER CALLING---------------------------->
         <div> 
		 <?php include "includes/header.php";
		 include 'db/db.php';
		 $sql_home="select * from home where status='1' order by id DESC";
		 $res_home=mysql_query($sql_home);
		 $result_home=mysql_fetch_array($res_home);
		  ?>
		 </div>
		 <!------------------------------------------------THE LEFT SIDE---------------------------->
     <div class="bod_home">
		 <div class ="left">
		    <!--------------------innovation---------------->
            <div class="ainn_home">
            <p><img src="icons/logo1.png" title="Innovation is Nutrition, healthy diet recipes, weight loss" alt="logo, diet health food recipes"><b class="m2">NNOVATION</b></p>
            </div>
			<!--------------------text--------------------->
            <div class="text_home_left"><?=$result_home['content']?></div> 
			<!----------------------diet------------------------>
            <div class="diet_img"><img src="uploads/<?=$result_home['image']?>" alt="<?=$result_home['image']?>" height="395" width="675" title="Innovation is Nutrition, healthy diet recipes, weight loss"></div>
			<!--------------------menu-------------------------->
			<div class="ainn_home">
			<p><img src="icons/soup.png" title="Innovation is Nutrition, healthy diet recipes, weight loss" alt="diet, diet health food recipes"><b class="m2">MENU</b></p>   
			</div>
			
			<?php
		    include 'db/db.php';
		    $sql_innovation_menu="select * from innovation_menu where status='1' order by id asc";
		    $res_innovation_menu=mysql_query($sql_innovation_menu);
			
		    while($result_innovation_menu=mysql_fetch_array($res_innovation_menu))
			{ ?> 
			<!--------------menu group-------------------------->
			 <div class="a">  <div><?=$result_innovation_menu['title']?></div><img src="uploads/<?=$result_innovation_menu['image']?>" alt="<?=$result_innovation_menu['image']?>" width="100" title="menu"> </div>
			 <?php }
			 ?>
			

			
			 <!--------------hot deals---------------------------->
			 <div class="ainn_home">
			 <p><img src="icons/hot.png" title="Innovation is Nutrition, healthy diet recipes, weight loss" alt="healthy, diet health food recipes"><b class="m2">HOT DEALS</b></p>   
			 </div>
			 <!---------------------hot deal group-------------->
			 <div>
			 <!-------big deals---------------------------------->
			 </div>
			 
			 
			 
			<?php
		    include 'db/db.php';
		    $sql_innovation_hotdeal="select * from innovation_hotdeal where status='1' order by id asc";
		    $res_innovation_hotdeal=mysql_query($sql_innovation_hotdeal);
			
		    while($result_innovation_hotdeal=mysql_fetch_array($res_innovation_hotdeal))
			{ ?> 
			<div>
			</div>
			<!--------------menu group-------------------------->
			 <div class="b">  
			 <div class="b1"><img src="uploads/<?=$result_innovation_hotdeal['image']?>" alt="<?=$result_innovation_hotdeal['image']?>" width="100" title="Innovation is Nutrition, healthy diet recipes, weight loss"> </div>
			 <div class = "c"><?=$result_innovation_hotdeal['title']?></div>
			 <div><?=$result_innovation_hotdeal['content']?></div>
			 </div>
			 <?php }
			 ?>
			 
</div>
			 
		<!------------------------------------------------THE RIGHT SIDE---------------------------->
		 <div class ="right_home">
		 
		 	 <!-------------------follow us-------------------->
			 <div class="social_mediahome">
			 <div class="r1">
             <p><img src="icons/followus.png" title="Innovation is Nutrition, healthy diet recipes, weight loss" alt="follow us, diet health food recipes"><b class="m2">  Follow Us</b></p>
			 <!-------------follow us buttons--------------->
			 <div class="R2"> 
			 <a href="https://www.facebook.com/" target="_blank" rel="facebook, diet recipes, nutrition, weight loss"><img src="icons/facebook.png" title="facebook" alt="facebook, diet health food recipes"></a>
			 <a href="https://twitter.com/" target="_blank" rel="facebook, diet recipes, nutrition, weight loss"><img src="icons/twitter.png" title="twitter" alt="twitter, diet health food recipes"></a>
			 <a href="https://www.instagram.com/" target="_blank" rel="facebook, diet recipes, nutrition, weight loss"><img src="icons/instagram.png" title="instagram" alt="instagram, diet health food recipes"></a>
			 <img src="icons/plus.png" title="plus" alt="plus diet health food recipes"> 
			 </div>
			 
			 </div>
			 </div>
			 
			 
			  <!-------------------bmi caculator-------------------->
			  
			  
			  
	  
			  
			  <div class="calculation_home">
			  <div class="r1">
              <p><img src="icons/bmi.png" title="Innovation is Nutrition, healthy diet recipes, weight loss" alt="bmi calculator, diet health food recipes"><b class="m2">  BMI calculator</b></p>
		      <div class="R3">
			  <form id="Calculator" name="form" method="post" action="">
	          <div class="R3"> 
			  <label>Gender:</label><input type="radio" name="radio" id="Male_r" value="Male" /><label>Male</label>
			  <input type="radio" name="radio" id="Female_r" value="Female" />Female
			  </div>
			  <div class="R3"><label>Weight:</label><input class="bmi" type="text" name="weight_txt" id="weight_id" size="5" /><label class="unbold">Kg</label></div>
			  <div class="R3"><label>Height:</label><input class="bmi1" type="text" name="height_txt" id="height_id"  size="5"/><label class="unbold">Cm</label></div>
			  <DIV class="R2">
			  
			  <input class="cal_home_1"  style="cursor:pointer" type="button" value="CALCULATE" id="cal_bmi" onclick="calculate()"/></div>
	  		  </form>
		      </div>
				
		      </div>
              </div>
			 <!--------------------calculate function------------------------------->
			
			  <!-------------------unit conversation-------------------->
			  <div class="conversion_home">
			  <div class="r1">
			  <p><img src="icons/unit.png" title="Innovation is Nutrition, healthy diet recipes, weight loss" alt="unit conversion, diet health food recipes" ><b class="m2">  UNIT conversion</b></p>
			  <form id="Conversion" name="form" method="post" action="">
			  <div class="R3">
			  
			  <div class="unit">
			  <input class="center_home" type="text" name="from" id="from_txt" size="12" onchange="convert()"/>
			  <select class="R6" id="volume_id1"   onchange="convert()">
              <option value="Fluidounces">Fluid ounce</option>
              <option value="Gallons">Gallon</option>
              <option value="Liters">Liter</option>
              <option value="Teaspoon">Tea spoon</option>
			  <option value="Cups">Cup</option>
              </select>
			  
			  </div>
			  </div>
			  <div class="R2_eq"><b>=</b></div>
			  <div class="R3">
			  
			  <div class="unit1">
			  <input class="center_home" type="text" name="to" id="to_txt"  size="12" />
			  <select class="R6" id="volume_id2" onchange="convert()" >
              <option value="Fluidounces">Fluid ounce</option>
              <option value="Gallons">Gallon</option>
              <option value="Liters">Liter</option>
              <option value="Teaspoon">Tea spoon</option>
			  <option value="Cups">Cup</option>
              </select>
			
			  </div>
			  </div>
	  		  </form>
			  
			  
			  
			  
			  
			  
			  </div>
			  </div>
			  <!-------------------Advertisement-------------------->  
	
		 <?php
		 include 'db/db.php';
		 $sql_panera="select * from panera where status='1' order by id DESC";
		 $res_panera=mysql_query($sql_panera);
		 $result_panera=mysql_fetch_array($res_panera);
		 ?>
 
			  <div class="advertize_home"><img src="uploads/<?=$result_panera['image']?>" alt="<?=$result_panera['image']?>" width="275" height="240" title="Innovation is Nutrition, healthy diet recipes, weight loss"></div>
			  </div>
			  <div class="rhi_head">
		   	  </div>		
              </div>
			  <?php include "includes/footer.php"; ?>
			  </div>
	     </div>

</div>
</body>

</html>