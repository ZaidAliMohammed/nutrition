-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 01, 2016 at 07:30 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `innovation`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `title` varchar(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`title`, `id`, `content`, `status`) VALUES
('1', 1, '<p>Innovation is a new idea, more effective device or process.Innovation can be viewed as the application of better solutions that meet new requirements, unarticulated needs, or existing market needs. This is accomplished through more effective.Innovation is a new idea, more effective device or process.Innovation can be viewed as the application of better solutions that meet new requirements, unarticulated needs, or existing market needs. This is accomplished through more effectiveInnovation is a new idea, more effective device or process.Innovation can be viewed as the application of better solutions that meet new requirements, unarticulated needs, or existing market needs. This is accomplished through more effective.</p>\r\n', 1),
('2', 4, '<p>The noun splendor refers to something that is magnificent or grand. If your prom was held in a luxurious ballroom with elegant decor, you might note the splendor of the setting.<br />\r\nThe noun splendor has its roots in the Latin word splendere, which means bright. Splendid, splendiferous, and resplendent are all related adjectives used to describe grand, magnificent, and brilliant things. Splendor usually has the connotation of luxury or quality, as in &quot;the splendor of Balmoral castle,&quot; or &quot;the splendor of the view at the Grand Canyon.&quot;</p>\r\n', 1),
('3', 5, '<p>Innovation is a new idea, more effective device or process.Innovation can be viewed as the application of better solutions that meet new requirements, unarticulated needs, or existing market needs. This is accomplished through more effective.Innovation is a new idea, more effective device or process.Innovation can be viewed as the application of better solutions that meet new requirements, unarticulated needs, or existing market needs. This is accomplished through more effectiveInnovation is a new idea, more effective device or process.Innovation can be viewed as the application of better solutions that meet new requirements, unarticulated needs, or existing market needs. This is accomplished through more effective.</p>\r\n', 1);

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE IF NOT EXISTS `home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `title`, `content`, `image`, `status`) VALUES
(5, 'NNOVATION', 'Innovation is a new idea, more effective device or process. Innovation can be viewed as the application of better solutions that meet new requirements, unarticulated needs, or existing market needs.This is accomplished through more effective.', '03302016060649.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `innovation_flipbook`
--

CREATE TABLE IF NOT EXISTS `innovation_flipbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `image` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `innovation_flipbook`
--

INSERT INTO `innovation_flipbook` (`id`, `title`, `image`, `status`) VALUES
(30, 'page2', '2.jpg', 1),
(31, 'page3', '3.jpg', 1),
(32, 'page4', '4.jpg', 1),
(33, 'page5', '5.jpg', 1),
(34, 'page6', '6.jpg', 1),
(35, 'page7', '7.jpg', 1),
(36, 'page8', '8.jpg', 1),
(37, 'page9', '9.jpg', 1),
(38, 'page10', '10.jpg', 1),
(39, 'page11', '11.jpg', 1),
(40, 'page12', '12.jpg', 1),
(41, 'page1', '1.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `innovation_hotdeal`
--

CREATE TABLE IF NOT EXISTS `innovation_hotdeal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `image` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `content` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `innovation_hotdeal`
--

INSERT INTO `innovation_hotdeal` (`id`, `title`, `image`, `content`, `status`) VALUES
(1, 'Big Deal', '03302016095813.png', 'Soup + Salad + Sandwich + Dessert + Drink', 1),
(2, 'Medium Deal', '03302016095900.png', 'Soup + Salad + Meal + Dessert + Water', 1),
(3, 'Small Deal', '03302016095927.png', 'Soup + Sandawich + Drink', 1);

-- --------------------------------------------------------

--
-- Table structure for table `innovation_imageslider`
--

CREATE TABLE IF NOT EXISTS `innovation_imageslider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `content` varchar(1000) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `innovation_imageslider`
--

INSERT INTO `innovation_imageslider` (`id`, `title`, `content`, `status`) VALUES
(1, 'Wait 20 minutes!!', 'Wait 20 minutes before deciding whether to continue eating, because that&#39;s how long it takes your brain to receive the fullness signal.', 1),
(2, 'Ginger tea', 'There is no scientific evidence to support that drinking ginger tea is effective for weight loss. However, ginger tea is still considered a low-calorie and a healthy beverage that you can enjoy.', 1),
(3, 'Food portions', 'Develop a healthy habit of selecting your food portions.', 1),
(4, 'Dinner', 'Aim to have your dinner at least three hours before bedtime. Give your body a chance to digest and burn the last fuel of the day.', 1),
(5, 'Drinking water before meals', 'Drinking water, especially before your meals, makes you eat less by filling you up.', 1),
(6, 'Stress and belly fat', 'Research indicates that when you are stressed, your body secretes a hormone called &quot;cortisol&quot; that is associated with an increase in belly fat.', 1),
(7, 'Fad diets', 'Fad diet usually refers to eating patterns that promote short-term weight loss, usually with no concern for long-term weight maintenance, and enjoy temporary popularity.', 1),
(8, 'Dried fruits', 'Dried fruits are widely known for their ability to help digestion due to their high fiber content.', 1),
(9, 'Oats', 'Oats protect against cardiovascular diseases by lowering LDL, known as &quot;the bad cholesterol&quot;.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `innovation_menu`
--

CREATE TABLE IF NOT EXISTS `innovation_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `image` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `innovation_menu`
--

INSERT INTO `innovation_menu` (`id`, `title`, `image`, `status`) VALUES
(2, 'SALADS', '03302016094103.png', 1),
(3, 'MEALS', '03302016094125.png', 1),
(4, 'SANDWICHES', '03302016094137.png', 1),
(5, 'DESSERTS', '03302016094156.png', 1),
(6, 'DRINKS', '03302016094212.png', 1),
(10, 'SOUPS', '03312016124055.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `panera`
--

CREATE TABLE IF NOT EXISTS `panera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `panera`
--

INSERT INTO `panera` (`id`, `title`, `image`, `status`) VALUES
(2, 'Banner', '03312016092707.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `splendor_video`
--

CREATE TABLE IF NOT EXISTS `splendor_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `link` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `splendor_video`
--

INSERT INTO `splendor_video` (`id`, `title`, `link`, `status`) VALUES
(30, '', 'https://www.youtube.com/embed/huixQLJxMeE', 0),
(31, '1', 'https://www.youtube.com/embed/huixQLJxMeE', 0),
(32, '2', 'https://www.youtube.com/embed/huixQLJxMeE', 0),
(33, '4', 'https://www.youtube.com/embed/huixQLJxMeE', 0),
(34, '3', 'https://www.youtube.com/embed/huixQLJxMeE', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `control` varchar(50) NOT NULL,
  `email` varchar(25) NOT NULL,
  `confirmcode` varchar(20) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `created` date NOT NULL,
  `updated` date NOT NULL,
  `fax` varchar(16) NOT NULL,
  `mobile` varchar(16) NOT NULL,
  `country` varchar(50) NOT NULL,
  `gender` varchar(2) NOT NULL,
  `company` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `status`, `control`, `email`, `confirmcode`, `phone`, `created`, `updated`, `fax`, `mobile`, `country`, `gender`, `company`) VALUES
(1, 'hassan', 'hassan', 'e10adc3949ba59abbe56e057f20f883e', '1', 'Superadmin', 'hassan@browse-me.net', 'yes', '70663741asdasdad', '2014-12-18', '2014-12-18', '70663741', '70663741', 'liban', 'm', 'Browse-me'),
(3, 'hassan', 'hassan', 'e10adc3949ba59abbe56e057f20f883e', '1', 'Superadmin', 'hashjhas@hotmail.com', 'yes', '', '2014-12-18', '0000-00-00', '', '', '', '', ''),
(4, 'Admin', 'Admin', '14340575b0597ecd395cf48abcab1a14', '1', 'Superadmin', 'admin@browse-me.net', 'yes', '', '2014-12-19', '0000-00-00', '', '', '', '', '');
