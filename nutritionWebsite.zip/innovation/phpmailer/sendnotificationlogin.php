<?PHP
require_once("include/db.php");
require_once("include/membersite_config.php");
if($fgmembersite->CheckLogin()){
$useron=$fgmembersite->UserUsername();
$timezone = "Asia/Beirut";
if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone );
$today = date('d/m/Y');
$query = mysql_query("select c_id,created_by,updated from clients where updated_by='$useron'");
$count = 0 ;
while($res = mysql_fetch_array($query)){
	$cut_update = substr($res['updated'],0,10);
	if($cut_update == $today)
		++$count;
}
}
$mail = new phpmailer();
$mail->PluginDir = '../phpmailer/'; // relative path to the folder where PHPMailer's files are located
$mail->IsSMTP();
$mail->Port = 465;
$mail->Host = 'smtp.gmail.com'; // "ssl://smtp.gmail.com" didn't worked
$mail->IsHTML(true); // if you are going to send HTML formatted emails
$mail->Mailer = 'smtp';
$mail->SMTPSecure = 'ssl';

$mail->SMTPAuth = true;
$mail->Username = "ahmad.browseme@gmail.com";
$mail->Password = "Browseme2013";

$mail->SingleTo = true; // if you want to send mail to the users individually so that no recipients can see that who has got the same email.

$mail->From = "ahmad.browseme@gmail.com";
$mail->FromName = "From Ahmad";

$mail->addAddress($email,"ahmad@browse-me.net");

//$mail->addAddress("user.2@gmail.com","User 2");

//$mail->addCC("user.3@ymail.com","User 3");
//$mail->addBCC("user.4@in.com","User 4");


$mail->Subject = "Signup | Verification";
$mail->Body = $message;


if(!$mail->Send())
    echo "Message was not sent <br />PHP Mailer Error: " . $mail->ErrorInfo;
else
    echo "Message has been sent";
echo "<div id='success'>success</div>";
?>
</body>
</html>