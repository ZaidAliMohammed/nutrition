<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="includes/js.js"></script>
<script src="includes/jquery-1.11.3.js"></script>
<link rel="stylesheet" type="text/css" href="includes/css.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<title>Innovation, Splendor, Our Vision</title>





<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google-site-verification" content="_E9bflB0E_wGFcR1wGyHfzUjwkcBj1_OYTcchkUSKuU" />
<meta http-equiv="cache-control" content="no-cache,no-store,must-revalidate">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="classification" content="Innovation, innovation, healthy food, weight loss, web, website, nutrition, diet, diet recipes, splendor, nutrition recipes, food recipes, e-marketing, beirut, lebanon"/>
<meta name="category" content="nutrition website lebanon, healthy food website lebanon, nutrition recipes lebanon, diet food recipes lebanon, diet decipes lebanon,  beirut"/>
<meta name="subject" content="low cal Lebanon , nutrition Website, weight loss Lebanon, diet food Lebanon" />
<meta name="author" content="Browse Me, By Zaid Mohammed">
<meta name="robots" content="index,follow" />


<meta name="description" content="About Us, innovation, splendor, what we do?, where do we see outselves in the future?"/>

<meta property="og:title" content="Article Title">
<meta property="og:type" content="article">
<meta property="og:url" content="http://www.eatingwell.com/recipes_menus/collections/healthy_diet_recipes">
<meta property="og:image" content="http://www.healthquestkansas.com/wp-content/uploads/2016/01/Diet.jpg">


<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@username">
<meta name="twitter:title" content="Cardamom Donut Bites with Orange-Honey Glaze">
<meta name="twitter:description" content="Small article description.">


<link rel="publisher" href="https://plus.google.com/example">

<h1></h1>



</head>



<body>

<div class="totalhome">
  <div> 
  <?php include "includes/header.php";
		 include 'db/db.php';
		 $sql_innovation="select * from about where status='1' and title='1' order by id DESC";
		 $res_innovation=mysql_query($sql_innovation);
		 $result_innovation=mysql_fetch_array($res_innovation);
		 
		 $sql_splendor="select * from about where status='1' and title='2' order by id DESC";
		 $res_splendor=mysql_query($sql_splendor);
		 $result_splendor=mysql_fetch_array($res_splendor);
		 
		 $sql_whatwedo="select * from about where status='1' and title='3' order by id DESC";
		 $res_whatwedo=mysql_query($sql_whatwedo);
		 $result_whatwedo=mysql_fetch_array($res_whatwedo);
		 
		 $sql_panera="select * from panera where status='1' order by id DESC";
		 $res_panera=mysql_query($sql_panera);
		 $result_panera=mysql_fetch_array($res_panera);
		 
		 $sql_innovation_menu="select * from innovation_menu where status='1' order by id ASC";
		 $res_innovation_menu=mysql_query($sql_innovation_menu);
	
  ?>
 
  </div>
  <div class="bod_home_about">
  <!------left side--->
  <div class ="left">
  
            <!------innovation--->
            <div class="ainn_home">
			
			
            <p><div class="marginleft_about"><img src="icons/logo1.png" title="innovation" alt="logo, diet health food recipes"><b class="m2">NNOVATION</b></p></div>
            </div>
            <div class="text_home_left about_text">
			<div class="marginleft_about"><?=$result_innovation['content']?></div>
		    </div> 
			
			<!------splendor--->
			<div class="ainn_home">
            <div class="marginleft_about"><p><img src="icons/splendor.png" title="splendor" alt="logo, diet health food recipes"><b class="m2">PLENDOR</b></p></div>
            </div>
            <div class="text_home_left about_text">
			<div class="marginleft_about"><?=$result_splendor['content']?></div>
		    </div> 
	
			<!------our vision--->
			<div class="ainn_home">
            <div class="marginleft_about"><p><b class="m2_about">OUR VISION</b></p></div>
			<div class="marginleft_about"><p><b class="m3_about">WHAT WE DO?</b></p></div>
            </div>
            <div class="text_home_left about_text">
			<div class="m4_about"><div class="marginleft_about"><?=$result_whatwedo['content']?></div>
		    <b class="m6_about"><div class="marginleft_about1">WHERE DO WE SEE OURSELVES IN THE FUTURE?</div></b>
			</div>

			</div> 
			
	         <!------RIGHT side--->

	
	
		 	 <!-------------------about photo-------------------->

			</div>
			<div class="right_about">
		    <div class="about_menu">

			
			<img src="icons/aboutus.jpg" title="aboutus" alt="logo, diet health food recipes" width="275" height="450" >

		
	
			 
	        </div>

    		<div class="advertize_home_about"><img src="uploads/<?=$result_panera['image']?>" alt="<?=$result_panera['image']?>" width="275" height="235" title="panera"></div>
			 </div>
			 </div>	 
			 </div>
			 </div>
	         </div>
  <?php include "includes/footer.php"; ?>
</div>

</body>
</html>