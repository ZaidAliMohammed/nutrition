<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<title>Innovation, menu, hot deals, bmi calculator, unit conversion</title>



<meta name="description" content="Innovation is new good idea, provides solutions including: menu and hot deals, bmi calculator, unit conversion"/>

<meta property="og:title" content="Article Title">
<meta property="og:type" content="article">
<meta property="og:url" content="http://www.eatingwell.com/recipes_menus/collections/healthy_diet_recipes">
<meta property="og:image" content="http://www.healthquestkansas.com/wp-content/uploads/2016/01/Diet.jpg">


<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@username">
<meta name="twitter:title" content="Cardamom Donut Bites with Orange-Honey Glaze">
<meta name="twitter:description" content="Small article description.">

<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="publisher" href="https://plus.google.com/example">



</head>

<body>
<?php include "home.php"; ?>
</body>
</html>