<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="includes/jquery-1.11.3.js"></script>
<script type="text/javascript" src="includes/js.js"></script>

<link rel="stylesheet" type="text/css" href="includes/css.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<title>Contact Us - Send Message</title>




<meta name="description" content="First Name, Last Name, Email, Phone, Company, Country, Message, Code, Send Query!"/>

<meta property="og:title" content="Article Title">
<meta property="og:type" content="article">
<meta property="og:url" content="http://www.eatingwell.com/recipes_menus/collections/healthy_diet_recipes">
<meta property="og:image" content="http://www.healthquestkansas.com/wp-content/uploads/2016/01/Diet.jpg">


<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@username">
<meta name="twitter:title" content="Cardamom Donut Bites with Orange-Honey Glaze">
<meta name="twitter:description" content="Small article description.">

<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="publisher" href="https://plus.google.com/example">




<h1></h1>





</head>

<body>

<div class="totalhome">



          <!------------------------------------------------THE HEADER CALLING---------------------------->    
		 <?php include "includes/header.php"; ?>
		 <div class="bod_home_contact">
		        
		 		<iframe class="googlemap" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3311.834225335921!2d35.50359270784795!3d33.8939230220201!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0000000000000000%3A0xb789bd61b173f6e1!2sMohammed+Al-Amin+Mosque!5e0!3m2!1sen!2slb!4v1460974145470" width="520" height="360" frameborder="0" style="border:0" allowfullscreen>
                </iframe>
				<div class="contact_address">
				<p>Adress : Down Town | Aazariye Bldg | Bloc A1 | Office 504</p>
				<p>Tel/fax: +961 (01) 99 32 32  +961 (70) or (71) 99 32 32</p>
				<p>E-mail: info@adwaysgroup.com | Website: www.adwaysgroup.com</p>
		        </div>
		 
		 <form id="form_contact" name="form_contact" method="post"  action="javascript:void(0)">
				<div class="R3_1"><label>First Name:</label><input class="border_contact1" type="text" name="firstname_txt" id="firstname_id"/></div>
				<div class="R3_2"><label>Last Name:</label><input class="border_contact2" type="text" name="lastname_txt" id="lastname_id"/></div>
				<div class="R3_3"><label>Company:</label><input class="border_contact3" type="text" name="company_txt" id="company_id"/></div>
				<div class="R3_4"><label>Country:</label><select class="border_contact4"  name="country_txt"  id="contact_id" onchange="changecountry()"/>
				<option value="">Select Country</option>
				<option value="213">Algeria</option>
				<option value="376">Andorra</option>
				<option value="244">Angola</option>
				<option value="1264">Anguilla</option>
				<option value="1268">Antigua Barbuda</option>
				<option value="54">Argentina</option>
				<option value="374">Armenia</option>
				<option value="297">Aruba</option>
				<option value="61">Australia</option>
				<option value="43">Austria</option>
				<option value="994">Azerbaijan</option>
				<option value="1242">Bahamas</option>
				<option value="973">Bahrain</option>
				<option value="880">Bangladesh</option>
				<option value="1246">Barbados</option>
				<option value="375">Belarus</option>
				<option value="32">Belgium</option>
				<option value="501">Belize</option>
				<option value="229">Benin</option>
				<option value="1441">Bermuda</option>
				<option value="975">Bhutan</option>
				<option value="591">Bolivia</option>
				<option value="387">Bosnia Herzegovina</option>
				<option value="267">Botswana</option>
				<option value="55">Brazil</option>
				<option value="673">Brunei</option>
				<option value="359">Bulgaria</option>
				<option value="226">Burkina Faso</option>
				<option value="257">Burundi</option>
				<option value="855">Cambodia</option>
				<option value="237">Cameroon</option>
				<option value="1">Canada</option>
				<option value="238">Cape Verde Islands</option>
				<option value="1345">Cayman Islands</option>
				<option value="236">Central African Republic</option>
				<option value="56">Chile</option>
				<option value="86">China</option>
				<option value="57">Colombia</option>
				<option value="269">Comoros</option>
				<option value="242">Congo</option>
				<option value="682">Cook Islands</option>
				<option value="506">Costa Rica</option>
				<option value="385">Croatia</option>
				<option value="53">Cuba</option>
				<option value="90392">Cyprus North</option>
				<option value="357">Cyprus South</option>
				<option value="42">Czech Republic</option>
				<option value="45">Denmark</option>
				<option value="253">Djibouti</option>
				<option value="1809">Dominica</option>
				<option value="1809">Dominican Republic</option>
				<option value="593">Ecuador</option>
				<option value="20">Egypt</option>
				<option value="503">El Salvador</option>
				<option value="240">Equatorial Guinea</option>
				<option value="291">Eritrea</option>
				<option value="372">Estonia</option>
				<option value="251">Ethiopia</option>
				<option value="500">Falkland Islands</option>
				<option value="298">Faroe Islands</option>
				<option value="679">Fiji</option>
				<option value="358">Finland</option>
				<option value="33">France</option>
				<option value="594">French Guiana</option>
				<option value="689">French Polynesia</option>
				<option value="241">Gabon</option>
				<option value="220">Gambia</option>
				<option value="7880">Georgia</option>
				<option value="49">Germany</option>
				<option value="233">Ghana</option>
				<option value="350">Gibraltar</option>
				<option value="30">Greece</option>
				<option value="299">Greenland</option>
				<option value="1473">Grenada</option>
				<option value="590">Guadeloupe</option>
				<option value="671">Guam</option>
				<option value="502">Guatemala</option>
				<option value="224">Guinea</option>
				<option value="245">Guinea Bissau</option>
				<option value="592">Guyana</option>
				<option value="509">Haiti</option>
				<option value="504">Honduras</option>
				<option value="852">Hong Kong</option>
				<option value="36">Hungary</option>
				<option value="354">Iceland</option>
				<option value="91">India</option>
				<option value="62">Indonesia</option>
				<option value="98">Iran</option>
				<option value="964">Iraq</option>
				<option value="353">Ireland</option>
				<option value="39">Italy</option>
				<option value="1876">Jamaica</option>
				<option value="81">Japan</option>
				<option value="962">Jordan</option>
				<option value="7">Kazakhstan</option>
				<option value="254">Kenya</option>
				<option value="686">Kiribati</option>
				<option value="850">Korea North</option>
				<option value="82">Korea South</option>
				<option value="965">Kuwait</option>
				<option value="996">Kyrgyzstan</option>
				<option value="856">Laos</option>
				<option value="371">Latvia</option>
				<option value="961">Lebanon</option>
				<option value="266">Lesotho</option>
				<option value="231">Liberia</option>
				<option value="218">Libya</option>
				<option value="417">Liechtenstein</option>
				<option value="370">Lithuania</option>
				<option value="352">Luxembourg</option>
				<option value="853">Macao</option>
				<option value="389">Macedonia</option>
				<option value="261">Madagascar</option>
				<option value="265">Malawi</option>
				<option value="60">Malaysia</option>
				<option value="960">Maldives</option>
				<option value="223">Mali</option>
				<option value="356">Malta</option>
				<option value="692">Marshall Islands</option>
				<option value="596">Martinique</option>
				<option value="222">Mauritania</option>
				<option value="269">Mayotte</option>
				<option value="52">Mexico</option>
				<option value="691">Micronesia</option>
				<option value="373">Moldova</option>
				<option value="377">Monaco</option>
				<option value="976">Mongolia</option>
				<option value="1664">Montserrat</option>
				<option value="212">Morocco</option>
				<option value="258">Mozambique</option>
				<option value="95">Myanmar</option>
				<option value="264">Namibia</option>
				<option value="674">Nauru</option>
				<option value="977">Nepal</option>
				<option value="31">Netherlands</option>
				<option value="687">New Caledonia</option>
				<option value="64">New Zealand</option>
				<option value="505">Nicaragua</option>
				<option value="227">Niger</option>
				<option value="234">Nigeria</option>
				<option value="683">Niue</option>
				<option value="672">Norfolk Islands</option>
				<option value="670">Northern Marianas</option>
				<option  value="47">Norway</option>
				<option value="968">Oman</option>
				<option value="680">Palau</option>
				<option value="507">Panama</option>
				<option value="675">Papua New Guinea</option>
				<option value="595">Paraguay</option>
				<option value="51">Peru</option>
				<option value="63">Philippines</option>
				<option value="48">Poland</option>
				<option value="351">Portugal</option>
				<option value="1787">Puerto Rico</option>
				<option value="974">Qatar</option>
				<option value="262">Reunion</option>
				<option value="40">Romania</option>
				<option value="7">Russia</option>
				<option value="250">Rwanda</option>
				<option value="378">San Marino</option>
				<option value="239">Sao Tome Principe</option>
				<option value="966">Saudi Arabia</option>
				<option value="221">Senegal</option>
				<option value="381">Serbia</option>
				<option value="248">Seychelles</option>
				<option value="232">Sierra Leone</option>
				<option value="65">Singapore</option>
				<option value="421">Slovak Republic</option>
				<option value="386">Slovenia</option>
				<option value="677">Solomon Islands</option>
				<option value="252">Somalia</option>
				<option value="27">South Africa</option>
				<option value="34">Spain</option>
				<option value="94">Sri Lanka</option>
				<option value="290">St. Helena</option>
				<option value="1869">St. Kitts</option>
				<option value="1758">St. Lucia</option>
				<option value="249">Sudan</option>
				<option value="597">Suriname</option>
				<option value="268">Swaziland</option>
				<option value="46">Sweden</option>
				<option value="41">Switzerland</option>
				<option value="963">Syria</option>
				<option value="886">Taiwan</option>
				<option value="7">Tajikstan</option>
				<option value="66">Thailand)</option>
				<option value="228">Togo</option>
				<option value="676">Tonga</option>
				<option value="1868">Trinidad Tobago</option>
				<option value="216">Tunisia</option>
				<option value="90">Turkey</option>
				<option value="7">Turkmenistan</option>
				<option value="993">Turkmenistan</option>
				<option value="1649">Turks Caicos Islands</option>
				<option value="688">Tuvalu</option>
				<option value="256">Uganda</option>
				<option value="44">UK</option>
				<option value="380">Ukraine</option>
				<option value="971">United Arab Emirates</option>
				<option value="598">Uruguay</option>
				<option  value="1">USA</option>
				<option value="7">Uzbekistan</option>
				<option value="678">Vanuatu</option>
				<option value="379">Vatican City</option>
				<option value="58">Venezuela</option>
				<option value="84">Vietnam</option>
				<option value="84">Virgin Islands British</option>
				<option value="84">Virgin Islands US</option>
				<option value="681">Wallis Futuna</option>
				<option value="969">Yemen (North)</option>
				<option value="967">Yemen (South)</option>
				<option value="260">Zambia</option>
				<option value="263">Zimbabwe</option></select></div>
			
				<div class="R3_5">Phone:<input class="border_contact5" type="text" name="phone_txt" id="phone_id"/></div>
				<div class="R3_6">Mobile:<input class="border_contact6" type="text" name="mobile_txt" id="mobile_id"/></div>
				<div class="R3_7"><label>Email:</label><input class="border_contact7" type="text" name="email_txt" id="email_id"/></div>
				<div class="R3_10"><label><div class="mes_top">Message:</div></label><textarea style="overflow:auto;resize:none" rows="6" cols="50" class="border_contact10" name="message_txt" id="message_id"/></textarea></div>
				
				<div class="R3_8"><label>Code:</label>
				<div id="securitydiv">
				
				
				<div class="border_contact81">
				<img id="captcha2" src="secureimage/securimage_show.php" alt="CAPTCHA Image" height="30" />
				</div>
				<a href="#" onclick="document.getElementById('captcha2').src = 'secureimage/securimage_show.php?' + Math.random(); return false" class "captcha" rel="captcha, diet recipes, nutrition, weight loss">
				
				<div class="border_contact82">
				<div class="reloa_img"><img width="25" id="sc_id" height="25" border="0" align="bottom" onclick="this.blur()" alt="Reload Image" src="icons/reload.png">
                </div>
				</a>
				</div>
				
				
				<input class="border_contact83" type="text" name="code_txt" id="code_id"/>
                </div>
				</div>
				
                
				<div class="R3_9"><input class="border_contact9" style="cursor:pointer" type="submit" name="send_smt" id="send_smt" value="Send"/></div>
				
		</form>
		
		
		
		
		
		
		 </div>
		 <?php include "includes/footer.php"; ?>
		 </div>
</div>
</body>
</html>