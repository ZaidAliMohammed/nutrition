<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google-site-verification" content="_E9bflB0E_wGFcR1wGyHfzUjwkcBj1_OYTcchkUSKuU" />
<meta http-equiv="cache-control" content="no-cache,no-store,must-revalidate">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="description" content="Innovation is new good idea, provides solutions including: menu and hot deals, bmi calculator, unit conversion"/>
<meta name="classification" content="Innovation, innovation, healthy food, weight loss, web, website, nutrition, diet, diet recipes, splendor, nutrition recipes, food recipes, e-marketing, beirut, lebanon"/>
<meta name="category" content="nutrition website lebanon, healthy food website lebanon, nutrition recipes lebanon, diet food recipes lebanon, diet decipes lebanon,  beirut"/>
<meta name="subject" content="low cal Lebanon , nutrition Website, weight loss Lebanon, diet food Lebanon" />
<meta name="author" content="Browse Me, By Zaid Mohammed">
<meta name="robots" content="index,follow" />