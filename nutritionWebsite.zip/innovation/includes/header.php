<div id="header">
			<div id="logo">
			<a href="home.php"><img src="icons/logo.png" title="Logo" alt="diet recipes, nutrition, weight loss"></a>
					<div class="right">
							<div class="left">
							<div class="enar">
							<a href="home.php" class="ar_en" rel="innovation home page">en</a>
							<b>/</b><a href="home.php" class="ar_en" rel="innovation home page">ar</a>
							</div>
							</div>
							<div class="rhi_head">
							<form id="form" name="form" method="post" action="">
							<input class="border" type="text" value=""/>
							<input class="border" style="cursor:pointer" type="submit" name="GO" id="GO" value="GO"/>
							</form>
							</div>
			        </div>
			</div>
    </div>
    <div class="body_page">
         <div id="navigation">
			    <div class="menue_l">
				<ul class="menue">
                <li><a href="home.php" rel="innovation home page">HOME</a></li>
				<li><a href="aboutus.php" rel="innovation about us page">ABOUT US</a></li>
				<li><a href="innovation.php" rel="innovation innovation page">INNOVATION</a></li>
				<li><a href="splendor.php" rel="innovation splendor page">SPLENDOR</a><li>
				<li><a class="align_contact" href="contactus.php" rel="innovation contact us page">CONTACT US</a></li>
				</ul>
				</div>
			</div>