







	$(document).ready(function() {
		
		$('#send_smt').click(function(){
		
				var firstname=$("#firstname_id").val();
				var lastname=$("#lastname_id").val();
				var company=$("#company_id").val();
				var contact=$("#contact_id").val();
				var phone=$("#phone_id").val();
				var mobile=$("#mobile_id").val();
				var email=$("#email_id").val();
				var code=$("#code_id").val();
				var message=$("#message_id").val();
				var value=false;
			if(firstname <=0){$("#firstname_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#firstname_id").css({"border":"2px solid #CCC"});value=true;}
			if(lastname <=0){$("#lastname_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#lastname_id").css({"border":"2px solid #CCC"});value=true;}
			if(company <=0){$("#company_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#company_id").css({"border":"2px solid #CCC"});value=true;}
			if(contact <=0){$("#contact_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#contact_id").css({"border":"2px solid #CCC"});value=true;}
			if(isNaN(phone)||phone==''){$("#phone_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#phone_id").css({"border":"2px solid #CCC"});value=true;}
			if(isNaN(mobile)||mobile==''){$("#mobile_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#mobile_id").css({"border":"2px solid #CCC"});value=true;}
				
			if(!validateEmail(email)){$("#email_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#email_id").css({"border":"2px solid #CCC"});value=true;}
				
			if(code <=0){$("#code_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#code_id").css({"border":"2px solid #CCC"});value=true;}
				
			if(message <=0){$("#message_id").css({"border":"2px solid #e52338"});value=false;}
				else{$("#message_id").css({"border":"2px solid #CCC"});value=true;}
				
			if(value==true){
				$.post("secureimage/compareimage.php",{'code':code}, 
	function(rq){
		if(rq==1)
			{
				var d=$("#form_contact").serialize();
		$.ajax({	
					url:'sendemail.php',
					type:'post',
					data:d,
					success:function(re){
						if(re==1){
						var boton = "button";
						swal({   
						title: "your message has been sent successfully!",  
						html: true ,
						confirmButtonColor: '#719500'
						});
						}else{alert (re)}
					},
					error:function(e){alert(e)}
				});
				
			}else{ $("#code_id").css({"border":"2px solid #e52338"});}
		});	
	}
		img = document.getElementById('code_id');
			img.src = 'secureimage/securimage_show.php?' + Math.random();  
		
		})

	})







function validateEmail(email) {var filter = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;if (filter.test(email)){return true;}else {return false;}}










	function calculate() 
	{ 

				var weight = document.getElementById("weight_id").value; 
				var height =  document.getElementById("height_id").value;
				var height1 = height / 100;
				var heightt = height1 * height1;
				var result = weight / heightt;
				
				
					if(weight == null || weight == "" || weight == 0 )
								    
                    {$("#weight_id").css({"border":"2px solid #e52338"});value=false;}
                    
				
				   	if(height == null || height == "" || height == 0)
								    
                    {$("#height_id").css({"border":"2px solid #e52338"});value=false;}
                  
				
				
					else if(result < 18.5)
					{			    
						var boton = "button";
						swal({   
							title: "Under Weight!",  
							html: true ,
							confirmButtonColor: '#719500'
						});
                    }
					else if(result > 18.5 && result < 24.9)
					{		
					var boton = "button";
						swal({   
							title: "Healthy Weight",  
							html: true ,
							confirmButtonColor: '#719500'
						});
					}
					else if(result > 25 && result < 29.9)
					{
						var boton = "button";
						swal({   
							title: "Over Weight",  
							html: true ,
							confirmButtonColor: '#719500'
						});  
					}
					else if (result > 30)
					{
						var boton = "button";
						swal({   
							title: "Obese",  
							html: true ,
							confirmButtonColor: '#719500'
						});
					}
					else 
					{
						var boton = "button";
						swal({   
							title: "Please enter the values!",  
							html: true ,
							confirmButtonColor: '#719500'
							
						});
					}

	}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	function convert()
	{ 
			var unit1 = document.getElementById("volume_id1");
			var unit2 = document.getElementById("volume_id2");
			var unit_v1 = unit1.options[unit1.selectedIndex].value;
			var unit_v2 = unit2.options[unit2.selectedIndex].value;
			var from =  document.getElementById("from_txt").value;
			var flo_gal = 0.0078 * from;
			var flo_lit = 0.03 * from;
			var flo_tea = 6 * from;
			var flo_cup = 0.125 * from;
			var gal_fl0 = 128 * from;
			var gal_lit = 3.785 * from;
		    var gal_tea = 768 * from;
			var gal_cup = 16 * from;
			var lit_fl0 = 33.8 * from;
			var lit_gal = 0.264 * from;
		    var lit_tea = 202.9 * from;
			var lit_cup = 4.226* from;
			var tea_fl0 = 0.166 * from;
			var tea_gal = 0.0013 * from;
		    var tea_lit = 0.005 * from;
			var tea_cup = 0.02 * from;
		    var cup_fl0 = 8 * from;
			var cup_gal = 0.062 * from;
		    var cup_lit = 0.236 * from;
			var cup_tea = 48 * from;

			if (unit_v1 == "Fluidounces" && unit_v2 == "Gallons")
			{		
			document.getElementById("to_txt").value = flo_gal;
			}
			else if (unit_v1 == "Fluidounces" && unit_v2 == "Liters")
			{
				document.getElementById("to_txt").value = flo_lit;
			}	
			else if (unit_v1 == "Fluidounces" && unit_v2 == "Teaspoon")
			{
				document.getElementById("to_txt").value = flo_tea;
			}	
			else if (unit_v1 == "Fluidounces" && unit_v2 == "Cups")
			{
				document.getElementById("to_txt").value = flo_cup;
			}
			else if (unit_v1 == "Gallons" && unit_v2 == "Fluidounces")
			{
				document.getElementById("to_txt").value = gal_fl0;
			}	
			else if (unit_v1 == "Gallons" && unit_v2 == "Liters")
			{
				document.getElementById("to_txt").value = gal_lit;
			}	
			else if (unit_v1 == "Gallons" && unit_v2 == "Teaspoon")
			{
				document.getElementById("to_txt").value = gal_tea;
			}
			else if (unit_v1 == "Gallons" && unit_v2 == "Cups")
			{
				document.getElementById("to_txt").value = gal_cup;
			}
			else if (unit_v1 == "Liters" && unit_v2 == "Fluidounces")
			{
				document.getElementById("to_txt").value = lit_fl0;
			}	
			else if (unit_v1 == "Liters" && unit_v2 == "Gallons")
			{
				document.getElementById("to_txt").value = lit_gal;
			}
			else if (unit_v1 == "Liters" && unit_v2 == "Teaspoon")
			{
				document.getElementById("to_txt").value = lit_tea;
			}
			else if (unit_v1 == "Liters" && unit_v2 == "Cups")
			{
				document.getElementById("to_txt").value = lit_cup;
			}
			else if (unit_v1 == "Teaspoon" && unit_v2 == "Fluidounces")
			{
				document.getElementById("to_txt").value = tea_fl0;
			}	
			else if (unit_v1 == "Teaspoon" && unit_v2 == "Gallons")
			{
				document.getElementById("to_txt").value = tea_gal;
			}
			else if (unit_v1 == "Teaspoon" && unit_v2 == "Liters")
			{
				document.getElementById("to_txt").value = tea_lit;
			}
			else if (unit_v1 == "Teaspoon" && unit_v2 == "Cups")
			{
				document.getElementById("to_txt").value = tea_cup;
			}
			else if (unit_v1 == "Cups" && unit_v2 == "Fluidounces")
			{
				document.getElementById("to_txt").value = cup_fl0;
			}	
			else if (unit_v1 == "Cups" && unit_v2 == "Gallons")
			{
				document.getElementById("to_txt").value = cup_gal;
			}
			else if (unit_v1 == "Cups" && unit_v2 == "Liters")
			{
				document.getElementById("to_txt").value = cup_lit;
			}
			else if (unit_v1 == "Cups" && unit_v2 == "Teaspoon")
			{
				document.getElementById("to_txt").value = cup_tea;
			}
			else
			{
				var boton = "button";
						swal({   
							title: "Please enter another unit!",  
							html: true ,
							confirmButtonColor: '#719500'
							
						});
			}	
    }		
			
	