<div id="footer">
        <div class="foot_lef">© 2016 Splendor. All rights reserved.</div>	   
        <div class="list_menu_foot">	
        <ul>
		<li> <a href="home.php" rel="innovation home page">HOME</a></li>  | 
		<li><a href="aboutus.php" rel="innovation about us page">ABOUT US</a></li>  | 
		<li><a href="innovation.php" rel="innovation innovation page">INNOVATION</a></li>  | 
		<li><a href="splendor.php" rel="innovation splendor page">SPLENDOR</a></li>  | 
		<li><a href="contactus.php" rel="innovation contact us page">CONTACT US</a></li>
		<div class="foot_rig">Powered By: <a href="http://www.browse-me.net/" target="blank" rel=" browse-me page"><div class="align_browseme"><img src="icons/browse.png"  title="browse-me" alt="web development, diet recipes, nutrition, weight loss"/></div></a></div>                     
	    </ul>
	    </div>	   
</div>
 