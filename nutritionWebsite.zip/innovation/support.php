<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php 
$_SESSION['multakans_page']='support_id';
?>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="includes/css.css">
<title>ALMULTAKANS</title>
<script type="text/javascript" src="includes/js.js"></script>
<script type="text/javascript" src="jssor/js/jquery-1.9.1.min.js"></script>
<?php include "includes/hover.php"; ?>



</head>

<body>

<div class="body_home">
<!-----------------------------------------------------------------HEADER BEGIN------------------------------------->

		 <?php include "includes/header.php"; ?>



<!-------------------------------------------------------------------HOME CONTENT  START------------------------------------->

<div class="content_support">
<img class="support_photo1" src="icons/support_photo1.jpg" width="785" height="235"/>

<div class="support_cont_txt">Support</div>
<div class="support_cont_txt1">You can send your Support to the Follow Address:</div>
<div class="support_cont_txt2">Audi Bank Ghobeire Section, Lebanon.</div>

<img class="bankaudi" src="icons/bankaudi.jpg" width="276" height="84"/>
<img class="children" src="icons/children.jpg" width="331" height="221"/>

<div class="support_cont_txt3">
<span style=" color:#c51079; font-size:20px; font-style:italic; font-weight:bold;">Swift code:</span>
<span style="font-size:20px;">AUDBLBBX |</span>
<span style=" color:#c51079; font-size:20px; font-style:italic; font-weight:bold;">Account Number :</span>  
<span style="font-size:20px;">01-813930 | Beirut - Lebanon</span>
</div>

<img class="youth" src="icons/youth.jpg" width="577" height="316"/>

<div class="thank_g">
<div class="youth_txt1">شكرا لدعم </div>
<div class="youth_txt2">جمعية الملتقى النسائي</div>
<div class="youth_txt3">تلاميذ بيروت</div>
</div>
<div class="doctore">
Doctore Alawiye Farhat<br />
President of The Women's Forum
</div>

 </div>
 <!-------------------------------------------------------------------HOME CONTENT  END------------------------------------->
 
 
 
 
  <!-----------------------------------------------------------------FOOTER BEGIN------------------------------------->
 
 
 <?php include "includes/footer.php"; ?>


</div>

</body>
</html>





















