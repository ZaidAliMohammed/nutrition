<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="includes/js.js"></script>
<script src="includes/jquery-1.11.3.js"></script>
<link rel="stylesheet" type="text/css" href="includes/css.css">
<!---<link rel="stylesheet" type="text/css" href="bootstrap-3.3.6-dist/css/bootstrap.min.css/">--->


<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<title>Menu and Hot Deals</title>




<meta name="description" content="Menu: Salads, Meals, Sandwitches, Desserts, Drinks, Soups ; Hot Deals: Big Deal, Medium Deal, Small Deal"/>



<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google-site-verification" content="_E9bflB0E_wGFcR1wGyHfzUjwkcBj1_OYTcchkUSKuU" />
<meta http-equiv="cache-control" content="no-cache,no-store,must-revalidate">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="expires" content="0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="classification" content="Innovation, innovation, healthy food, weight loss, web, website, nutrition, diet, diet recipes, splendor, nutrition recipes, food recipes, e-marketing, beirut, lebanon"/>
<meta name="category" content="nutrition website lebanon, healthy food website lebanon, nutrition recipes lebanon, diet food recipes lebanon, diet decipes lebanon,  beirut"/>
<meta name="subject" content="low cal Lebanon , nutrition Website, weight loss Lebanon, diet food Lebanon" />
<meta name="author" content="Browse Me, By Zaid Mohammed">
<meta name="robots" content="index,follow" />




<meta property="og:title" content="Article Title">
<meta property="og:type" content="article">
<meta property="og:url" content="http://www.eatingwell.com/recipes_menus/collections/healthy_diet_recipes">
<meta property="og:image" content="http://www.healthquestkansas.com/wp-content/uploads/2016/01/Diet.jpg">


<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="@username">
<meta name="twitter:title" content="Cardamom Donut Bites with Orange-Honey Glaze">
<meta name="twitter:description" content="Small article description.">



<link rel="publisher" href="https://plus.google.com/example">




<h1></h1>




</head>

<body>
<div class="totalhome">
          <!------------------------------------------------THE HEADER CALLING---------------------------->    
		 <?php include "includes/header.php"; ?>
		 
		 
		 	<!--------------------menu-------------------------->
			 <div class="food_innovation1">
			 <div class="line1_innovation">
 
			 <p><b class="m2_innovation1"><img src="icons/soup.png" title="menu" alt="diet, diet health food recipes">MENU</b></p>   
		   	 </div>
			 <!--------------menu group-------------------------->
			 
			 <?php
		    include 'db/db.php';
		    $sql_innovation_menu="select * from innovation_menu where status='1' order by id asc";
		    $res_innovation_menu=mysql_query($sql_innovation_menu);
		    while($result_innovation_menu=mysql_fetch_array($res_innovation_menu))
			{ ?> 
			 <div class="a_innovation">  <div><?=$result_innovation_menu['title']?></div><img src="uploads/<?=$result_innovation_menu['image']?>" alt="<?=$result_innovation_menu['image']?>" title="menu"> </div>
             <?php }
			 ?>
			 
			 
			 
			 </div>
			 <!--------------hot deals---------------------------->
			 <div class="food_innovation2">  
			 </div>
			 <div class="line2_innovation">
			 <p><b class="m2_innovation2"><img src="icons/hot.png" title="hot deal" alt="healthy, diet health food recipes">HOT DEALS</b></b> 
			 <!---------------------deal group---------------------------------->



			 <?php
		    include 'db/db.php';
		    $sql_innovation_hotdeal="select * from innovation_hotdeal where status='1' order by id asc";
		    $res_innovation_hotdeal=mysql_query($sql_innovation_hotdeal);
		    while($result_innovation_hotdeal=mysql_fetch_array($res_innovation_hotdeal))
			{ ?> 
			 <div class="b_inovation1">
			 <div class="b1"> <img src="uploads/<?=$result_innovation_hotdeal['image']?>" alt="<?=$result_innovation_hotdeal['image']?>" title="hot deal"></div> 
			 <div class = "c"><?=$result_innovation_hotdeal['title']?></div>
			 <div><?=$result_innovation_hotdeal['content']?></div> 
			 </div>
			 <?php }
			 ?>
			 
 
             </div>
			 

			 
			 <p>&nbsp;</p>
			 <iframe class="flipbook"  style="width:600px;height:360px"  src="turnjs4/samples/magazine/flipbook.php?pageIndex=1"  seamless="seamless" scrolling="no" frameborder="0" allowtransparency="true"></iframe>
			 <iframe class="carousel" style="width:300px;height:360px"  src="carousel.php"></iframe>
			 
	
		 <div class="bod_home_innovation"> 
		 </div>
		 <?php include "includes/footer.php"; ?>
	    </div>
</div>
</div>
</body>
</html>