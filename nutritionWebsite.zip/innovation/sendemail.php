<?php
	if(isset($_POST['email_txt'])){
		$email=$_POST['email_txt'];
		$firstname=$_POST['firstname_txt'];
		$lastname=$_POST['lastname_txt'];
		$company=$_POST['company_txt'];
		$country=$_POST['country_txt'];
		$phone=$_POST['phone_txt'];
		$mobile=$_POST['mobile_txt'];
		$message=$_POST['message_txt'];
		$msg="
				<html>
				<head>
				<title></title>
				<style type='text/css'>
				body{text-align:center; background:#cccccc; margin:0; padding:0;}
				table{width:700px;}
				.logo{text-align:center; height:100px; border-bottom:3px solid #cccccc; font-size:40px; color:#6c6d6f; font-weight:bold;}
				tr{height:80px;}
				.empty{height:80px;}
				.title{font-size:40px; text-align:left; color:#000000; font-weight:bold; width:700px;}
				td{background:#fff; vertical-align:middle;color:#000000 ; font-size:20px; border-bottom:3px solid #cccccc;}
				.td1{border-right:3px solid #cccccc;}
				.td3{width:350px; height:80px; color:#6c6d6f; font-size:20px;  vertical-align:middle; text-align:center;  background:#fff ;}
				.noback{background:#cccccc;}
				.inf2{color:#503728; background:#fff; border-bottom:3px solid #cccccc; font-size:12pt; text-align:left;}
				a{text-decoration:none; color:#6c6d6f;}
				.td2 a{color:#503728;}
				</style>
				</head>
				<body>
				<div class='logo'><img src='http://browse-me.net/assets/icons/logo.png'/></div>
				<div class='empty'>&nbsp;</div>
				<table id='table' cellspacing='0' cellpadding='0'>
				<tr>
				<td class='noback' colspan='2'><div class='title'>Contect US</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>First Name</div></td>
				<td class='td2'><div class='data'>$firstname</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Last Name</div></td>
				<td class='td2'><div class='data'> $lastname &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Company</div></td>
				<td class='td2'><div class='data'>$company &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Country</div></td>
				<td class='td2'><div class='data'>$country &nbsp;</div></td>
				</tr>
				
				<tr>
				<td class='td1'><div class='inf'>Phone</div></td>
				<td class='td2'><div class='data'>$phone</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Mobile</div></td>
				<td class='td2'><div class='data'>$mobile &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Email</div></td>
				<td class='td2'><div class='data'>$email &nbsp;</div></td>
				</tr>
				<tr>
				<td class='td1'><div class='inf'>Message</div></td>
				<td class='td2'><div class='data'>$message &nbsp;</div></td>
				</tr>
				</table>
				<table>
				<tr style='height:25px'>
				<td class='inf2' colspan='2'>For anny enquiry  send Email :
				<a href='mailto:info@shopanfight.com'> info@enovation.com</a>
				</td>
				</tr>
				</table>
				</body>
				</html>";
			
				
				include_once("includes/class.phpmailer.php");
				$email="aref@browse-me.net";
				$mail = new phpmailer();
				$mail->CharSet = 'UTF-8';
				$mail->PluginDir = 'phpmailer/'; // relative path to the folder where PHPMailer's files are located
				$mail->IsSMTP();
				$mail->Port = 465;
				$mail->Host = 'mail.adwaysgroup.com'; // "ssl://smtp.gmail.com" didn't worked
				$mail->IsHTML(true); // if you are going to send HTML formatted emails
				$mail->Mailer = 'smtp';
				$mail->SMTPSecure = 'ssl';
				$mail->SMTPAuth = true;
				$mail->Username = "project@adwaysgroup.com";
				$mail->Password = "AdWays2014";
				$mail->SingleTo = true; // if you want to send mail to the users individually so that no recipients can see that who has got the same email.
				$mail->From = "project@adwaysgroup.com";
				$mail->FromName = $firstname;
				$mail->addAddress($email,"Browse Me, Admin ");
				//$mail->addAddress("info@newvisionlebanon.com","New Vision, Reception");
				//$mail->addCC("user.3@ymail.com","User 3");
				//$mail->addBCC("user.4@in.com","User 4");
				$mail->Subject = "innovation";
				//$file_to_attach=$_FILES['file'];
			//	$mail->AddAttachment( $_FILES['file']['tmp_name'],$_FILES['file']['name']);
				$mail->Body = $msg;
				if(!$mail->Send())
					$result= "<div class='error'>Message was not sent PHP Mailer Error: " . $mail->ErrorInfo."</div>";
				else
					$result= 1;
				    echo $result;
				//	}
	}
?>