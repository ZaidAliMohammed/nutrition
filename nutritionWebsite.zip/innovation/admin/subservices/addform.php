	<?php
	if(isset($_GET['id'])){
	$id=$_GET['id'];	
	}else{
		header("Location: servicesadmin.php");
	}
	?>    
    <form action="subservices/add-subcategory.php" method="post"  name="AddNew" id="AddNew"  enctype="multipart/form-data" >
				<input type="hidden" name="id" value="<?=$id?>" />
                <div id="leftform">
	            <div id="preview"></div>
					
                     <label>Title</label>
					 <input type="text" name="title" id="title" value="" class="inptext" />
                     <label>Status</label>
                     <select name="status" class="inpselect">
                        <option value="">Select Status</option>
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                     </select>                      
                         <label>Image</label>
                     <br />
                     <label>Dear User the pictures is less to 800 pixles</label>
					 <input type="text" name="image" id="img_link" disabled="disabled" value="" class="inptext" />
                     <label for="file" id="bro">Browse</label>
                     <input type="file" name="file" onchange="change_image(this.id)" id="file" style="display:none" />
				   </div>
				   <div id="bottomform">
				<label>Content</label>
					 <textarea name="content" id="content" class="txtarea"></textarea>
                <input type="submit" value="Add" name="submitform" class="submitform" />
                <input type="reset" value="reset" id="reset" />
                
				   </div>
			</form>