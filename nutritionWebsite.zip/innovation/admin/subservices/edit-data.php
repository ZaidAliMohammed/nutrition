<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$title=secureInput($_POST['title']);
$status=secureInput($_POST['status']);
$content=$_POST['content'];
$cat=$_POST['cat'];
$page='';
if($title ==''){
	echo '<div class="error">Please insert title</div>';
	exit;
	}else{	
  $q6 = mysql_query("UPDATE subservices SET title='$title',status='$status',s_id='$cat', content='$content' where id='$id'"); 
  if($q6)echo '<div class="success">Content was edited successfully</div>';
  else
  echo mysql_error();
 }
}
?>