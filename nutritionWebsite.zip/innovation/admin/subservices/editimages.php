<html>
<head>
<style>
body{
	font-family:arial;
}
form, h2{
	padding:0;
	margin:0;
}	
.ifp{
	width:450px;
}
.ifp:after{
	content:'.';display:block;clear:both;visibility:hidden;height:0;
}
.ifpl{
	float:left;
	width:120px;
	height:25px;
	font-size:10pt;
	color:#333;
}
.ifpr{
	float:left;
	width:300px;
	height:25px;
	margin-left:10px;
}
.ifpr input{
	font-size:10pt;
	color:#333;
}
.faraghifp{
	width:1px;
	height:20px;
}
.ifpm{
	height:30px;
	font-size:10pt;
	color:#333;
	line-height:20px;
}
</style>
<script type="text/javascript" src="../assets/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="../assets/js/jquery.form.js"></script>
</head>
<body>
<?php
include_once('../../db/db.php');
if(isset($_GET['id'])) { 
$id = intval($_GET['id']);
if($id <= 0) { 
die('The ID is invalid!'); 
} 
else {	
$q = mysql_query("select * from subservices where `id`='$id'");
$r = mysql_fetch_array($q);
?>

<script type="text/javascript" >
 $(document).ready(function() { 
		
            $('#photoimg').live('change', function()			{ 
			           $("#preview").html('');
			    $("#preview").html('<img border="0" src="../assets/images/loader.gif" alt="Uploading...."/>');
			$("#imageform").ajaxForm({
						target: '#preview'
		}).submit();
			});
        }); 
</script>
<style>
input{
	width:200px;
}
select{
	width:204px;
}
</style>
<div id='preview'></div>
<div class="faraghifp"></div>
<fieldset style="width:400px;">
<legend style="font-size:12pt;color:#333;">Edit Image</legend>
<form id="imageform" method="post" enctype="multipart/form-data" action='edit_image.php?id=<?php echo $r['id']; ?>'>
<div class="faraghifp"></div>
<div class="ifp2">
	<div class="ifpl2">
    	Image 
    </div>
    <div class="ifpr1">
     <input type="file" name="myfile" id="photoimg" />
    </div>
</div>

</form>
</fieldset>
<?php
}}
?>
<div style="height:50px;"></div>
</body>
</html>
