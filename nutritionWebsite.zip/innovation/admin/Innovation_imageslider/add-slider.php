<?php
include('../../db/db.php');
include ('../includes/thumb.php');
include '../secureInput.php';
if (isset ($_POST['submitform'])) {
	$title=secureInput($_POST['title']);
	$content=secureInput($_POST['content']);
	$status=secureInput($_POST['status']);
	

		$q6=mysql_query("insert into  innovation_imageslider (title,status,content) values('$title','$status','$content')") or die(mysql_error());
		echo'<div class="success">Content was added successfully.</div>';
				}
	
	
	
 
?>