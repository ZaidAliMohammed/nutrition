<div id="main-content">
   <div id="indicator"><strong>Logged in as : <?php echo $fgmembersite->UserFullName(); ?></strong>  </div>
 <div id="left-menu">
	   <?php include('includes/leftmenu.php'); ?>
 </div>
 <div id="pagecontent">
  <div id="content-left">
   <?php include('../db/db.php'); ?>
   <div class="top_link">
   <div class="left_link">
    <a href="javascript:backpage()" class="backbutton">Back</a>
   </div>
   <div class="right_link">
  <a href="javascript:void(0)" onclick="AddNew('Innovation_imageslider/addform.php','<?=$_SESSION['admin']?>')" class="addnewform">Add New</a>
  </div>
  </div>
   <form method='post' action='Innovation_imageslider/slider-delete.php' name="deleteForm" id="deleteForm">
     <div class="demo_jui" id="content_table">
          <?php include "Innovation_imageslider/table.php";?>
	 </div>
    <input id='delete' type='submit' class='button' name='delete' value='Delete Selected Items' onclick="return confirm('Do you wish to Delete Items?')"/>
   </form>
	</div>
     <div id="content-right">
	   <div id="contentAjax">
			<form action="Innovation_imageslider/add-slider.php" method="post"  name="AddNew" id="AddNew"  enctype="multipart/form-data" >
				   <div id="leftform">
	            <div id="preview"></div>
					
                     <label>Title</label>
					 <input type="text" name="title" id="title" value="" class="inptext" />
					  
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="">Select Status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
						 
						
                        
						
 
					 <br />
					  <label>Content</label><textarea name="content" id="content" class="txtarea"></textarea>
                     
				   </div>
				   <div id="bottomform">
					
				<input type="submit" value="Add" name="submitform" class="submitform" />
                <input type="reset" value="reset" id="reset" />
				   </div>
			</form>
		</div>
	</div>
 </div>
</div>

