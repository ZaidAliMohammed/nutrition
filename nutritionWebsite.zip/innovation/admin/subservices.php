<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Browse Me, Sub Services</title>
<?php include "include/link.php";?>
<script type="text/javascript">
$(document).ready(function() { 
    $('#AddNew').ajaxForm({ 
        target: '#preview', 
        success: function(response) { 
				if(response=='1')
				{
					$("#preview").html('<div class="success">Content was added successfully.</div>');
					$('#preview').fadeIn();
					var id=$("#cat_id").val();
				setTimeout(function(){
					$.post("subservices/table.php?id="+id,function(re){
					$("#content_table").html(re);
					$('#preview').fadeOut();
					$("#reset").click();
					})},2000);
				}else{
					$('#preview').fadeIn();
					$("#preview").html(response);
				}
        }
    });
});
function checkAll(){  
    var field = document.getElementsByName('checkbox[]');
	for (i = 0; i < field.length; i++)
 		if(document.deleteForm.CheckAll.checked == true){
		field[i].checked = true ;
	}else{
		field[i].checked = false ;
	}	
}
</script>
</head>
<body>
<?php
$_SESSION['admin']='subservices';
require_once('includes/header.php');
?>
<?php
require_once('subservices/content.php');
?>
<?php
require_once("includes/footer.php"); 
?>
</body>
</html>