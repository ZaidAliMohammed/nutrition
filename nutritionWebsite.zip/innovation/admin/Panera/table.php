 <?php
 if(!isset($_SESSION)){
	 session_start();
	 include "../../db/db.php";
	 ?>
     <script type="text/javascript">
	$(document).ready(function() { 
		$('#listcontent').dataTable( {
		  "aoColumnDefs": [
			  { 'bSortable': false, 'aTargets': [ 4 ] }
		   ]
		});
	});
	</script>
     <?php
 }?>
 
 <table cellpadding="0" cellspacing="0" border="0" class="table-list display" id="listcontent">
                <thead>
                    <tr valign="top">
                        <th align="left">ID</th>
						<th align="left">Title</th>
                        <th align="center">Image</th>
						<th align="center">Status</th>
                        <?php if(($_SESSION['control_of_user'])!='User'){ ?>
                        <th>Delete <input id="CheckAll" onclick="checkAll();" name="CheckAll" type="checkbox" /></th>
                        <?php } ?>
                    </tr>
                </thead>
				<tbody>
					<?php 
					$q=mysql_query("select * from panera order by id DESC");
					while($r=mysql_fetch_array($q)){ ?>
                    <tr id="<?=$r['id'];?>">
					   <td><?=$r['id'];?></td>
					   <td onclick="getEdit('Panera/editForm.php?id=<?=$r['id'];?>',<?=$r['id'];?>,'<?=$_SESSION['admin']?>')" class="pointertd"><?=substr($r['title'],0,10);?>..</td>
					   <td><?php 
							if($r['image']==''){?>
                              <a class="various fancybox.iframe" href="Panera/editimages.php?id=<?php echo $r['id'];?>">
                			<img border="0" src="assets/icons/add.png" />
                			</a>
							<?php }else{ ?>
							<a style="text-decoration:none;color:#333;" class="various" href="../uploads/<?php echo $r['image'];?>" title=""> 
                                                   <img src="../uploads/thumb/<?php echo $r['image'];?>" style="max-width:70px" border="0"/>
                       		</a> 
                            <a class="various fancybox.iframe" href="Panera/editimages.php?id=<?php echo $r['id'];?>">
                          	<img border="0" src="assets/icons/pencil.png" />
                             
                			</a>
                             <br />
                            <a href="javascript:deleteimage(<?=$r['id']?>,'<?=$_SESSION['admin']?>')">
                			<img border="0" src="assets/icons/delete.png" />
                			</a>
						<?php }?>
					   </td>

					   <td class="clickable" id="status<?=$r['id'];?>" onclick="changeStatus('Panera/status.php?id=<?=$r['id'];?>',<?=$r['id'];?>)">
					    <?php if($r['status']==1){?><img src="assets/icons/tick.png" /><?php }else{ ?><img src="assets/icons/cross.png" /><?php } ?>
					   </td>
					   <td align="center"><input type='checkbox' name='checkbox[]' id='checkbox[]' value="<?php echo $r['id'];?>" style="width:50px;" /></td>
					  </tr>
					<?php } ?>
	             </tbody>
             </table>