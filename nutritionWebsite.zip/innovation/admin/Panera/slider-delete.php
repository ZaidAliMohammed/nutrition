<?php
require_once('../../db/db.php');
if($_POST['delete'])
	{
		$checkbox = $_POST['checkbox'];
		$countCheck = count($_POST['checkbox']);
		for($i=0;$i<$countCheck;$i++)
		{               $del_id  = $checkbox[$i];
			            $query = "SELECT * FROM  panera WHERE `id`={$del_id}";
						$result = mysql_query($query);
						
						while($row = mysql_fetch_array($result)) {
								$fileToRemove = '../../uploads/'.$row['image'];
								if (file_exists($fileToRemove)) {
   													// yes the file does exist
   													unlink($fileToRemove);
								}
								$fileToRemove = '../../uploads/thumb/'.$row['image'];
								if (file_exists($fileToRemove)) {
   													// yes the file does exist
   													unlink($fileToRemove);
								}
						}

			$q1 = mysql_query("DELETE FROM `panera` WHERE id = '$del_id'");
			
		}
		header("Location: ../Panera.php");
	}
?>