<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$username=secureInput($_POST['username']);
$name=secureInput($_POST['name']);
$email=secureInput($_POST['email']);
$phone=secureInput($_POST['phone']);
$mobile=secureInput($_POST['mobile']);
$pass=secureInput($_POST['pass']);
$control=secureInput($_POST['control']);
if($username=='' || $name =='' || $email =='' || $control ==''){
	echo '<div class="error">Please insert the required fields(*)</div>';
	exit;
	}else{	
	$q=mysql_query("select * from users where email='$email' AND id !='$id'");
	if(mysql_num_rows($q)>0){
		echo '<div class="error">Data already exist!</div>';
	exit;
		}else{
		  $q6 = mysql_query("UPDATE users SET username='$username',password='$pass',name='$name',email='$email',phone='$phone',mobile='$mobile',control='$control' where id='$id'"); 
		  
		  echo '<div class="success">Data was edited successfully</div>';
		}
 }
}
?>