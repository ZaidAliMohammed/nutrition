<div id="preview"></div>
<form action="users/add-data.php" method="post"  name="AddNew" id="AddNew"  enctype="multipart/form-data" >
<div id="leftform">
		 <label>Username(*)</label>
		 <input type="text" name="username" id="username" value="" class="inptext" />
		 <label>Name(*)</label>
		 <input type="text" name="name" id="name" value="" class="inptext" />
		 <label>Email(*)</label>
		 <input type="text" name="email" id="email" value="" class="inptext" />
		 <label>Password(*)</label>
		 <input type="text" name="password" id="password" value="" class="inptext" />
		 <label>Control(*)</label>
		 <select name="control" class="inpselect">
		   <option value="Superadmin">Superadmin</option>
		   <option value="Admin">Admin</option>
		   <option value="User">User</option>
		 </select>
		 <label>Phone</label>
		 <input type="text" name="phone" id="phone" value="" class="inptext" />
		 <label>Mobile</label>
		 <input type="text" name="mobile" id="mobile" value="" class="inptext" />
</div>
<div id="bottomform">
<input type="submit" value="Add" name="submitform" class="submitform" />
</div>
</form>