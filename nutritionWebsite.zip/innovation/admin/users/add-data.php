<?php
include('../../db/db.php');
include('../secureInput.php');
if(isset($_POST['submitform'])){
$username=secureInput($_POST['username']);
$name=secureInput($_POST['name']);
$email=secureInput($_POST['email']);
$phone=secureInput($_POST['phone']);
$mobile=secureInput($_POST['mobile']);
$control=secureInput($_POST['control']);
$password=secureInput($_POST['password']);
$timezone = "Asia/Beirut";
					if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone );
	    $created = date('Y-m-d');
if($username=='' || $name =='' || $email =='' || $control =='' || $password ==''){
	echo '<div class="error">Please insert all the required field (*)</div>';
	}else{
	$q=mysql_query("select * from users where email='$email'");
	if(mysql_num_rows($q)>0){
		echo '<div class="error">Data already exist!</div>';
	exit;
		}else{
			$q6 = mysql_query("insert into users (username,name,email,phone,mobile,control,password,created,status,confirmcode) values ('$username','$name','$email','$phone','$mobile','$control','".md5($password)."','$created','1','yes') ") or die(mysql_error());
			echo'<div class="success">Content was added successfully.</div>';
		}
}
}
?>