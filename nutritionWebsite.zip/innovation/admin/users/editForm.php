<?php
include('../../db/db.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$qq=mysql_query("select * from users where id='$id'");
	$rr=mysql_fetch_array($qq);
	?>

	<div id="preview"></div>
	<form action="users/edit-data.php" method="post"  name="DataForm" id="DataForm"  enctype="multipart/form-data" >
	       <input type="hidden" name="id" id="id" value="<?=$rr['id']?>" class="inptext" />
		   <div id="leftform">
		         <label>Username(*)</label>
				 <input type="text" name="username" id="username" value="<?=$rr['username']?>" class="inptext" />
				 <label>Name(*)</label>
				 <input type="text" name="name" id="name" value="<?=$rr['name']?>" class="inptext" />
				 <label>Email(*)</label>
				 <input type="text" name="email" id="email" value="<?=$rr['email']?>" class="inptext" />
                  <label>Password(*)</label>
				 <input type="text" name="pass" id="pass" value="<?=$rr['password']?>" class="inptext" />
				 <label>Control(*)</label>
				 <select name="control" class="inpselect">
				   <option value="<?=$rr['control']?>"><?=$rr['control']?></option>
				   <option value="Superadmin">Superadmin</option>
				   <option value="Admin">Admin</option>
				   <option value="User">User</option>
				 </select>
				 <label>Phone</label>
				 <input type="text" name="phone" id="phone" value="<?=$rr['phone']?>" class="inptext" />
				 <label>Mobile</label>
				 <input type="text" name="mobile" id="mobile" value="<?=$rr['mobile']?>" class="inptext" />
		   </div>
		   <div id="bottomform">
			<input type="submit" value="Save" name="submitform" class="submitform" />
			</div>
		  </form>
<?php
	}
?>