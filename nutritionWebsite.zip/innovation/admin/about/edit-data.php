<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$title=secureInput($_POST['title']);
$content=str_replace(strtolower("new vision"),"New Vision",$_POST['content']);
$status=secureInput($_POST['status']);
if($title ==''){
	echo '<div class="error">Please insert title</div>';
	exit;
	}else{	
  $q6 = mysql_query("UPDATE about SET title='$title',status='$status', content='$content' where id='$id'"); 
  echo '<div class="success">Content was edited successfully</div>';
 }
}
?>