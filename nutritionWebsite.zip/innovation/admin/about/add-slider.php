<?php
include('../../db/db.php');
include '../secureInput.php';
if (isset ($_POST['submitform'])) {
	$title=secureInput($_POST['title']);
	$content=str_replace(strtolower("Browse Me"),"Browse ME",$_POST['content']);
	$status=secureInput($_POST['status']);
	if($title=='' or $content=='' or $status=='')
	echo '<div class="error">Please insert all the required field (*)</div>';
	else{
		$q6=mysql_query("insert into about (title,content,status) values('$title','$content','$status')") or die(mysql_error());
		 echo '<div class="success">Content was insert successfully</div>';
	}
	
 }
?>