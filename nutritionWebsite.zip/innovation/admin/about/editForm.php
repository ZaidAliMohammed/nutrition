<?php
include('../../db/db.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$qq=mysql_query("select * from about where id='$id'");
	$rr=mysql_fetch_array($qq);
	?>
	<div id="preview"></div>
	<form action="about/edit-data.php" method="post"  name="DataForm" id="DataForm"  enctype="multipart/form-data" >
	       <input type="hidden" name="id" id="id" value="<?=$rr['id']?>" class="inptext" />
		   <div id="leftform">
		   <label>Title</label>
					 <select name="title" class="inpselect">
			 <option value="<?=$rr['title']?>">Select Title</option>
			 <option value="1">Innovation</option>
			 <option value="2">Splendor</option>
			 <option value="3">What We Do</option>
		 </select>

                    
             <label>Status</label>
			<select name="status" class="inpselect">
				 <option value="<?=$rr['status']?>">Select Status</option>
				 <option value="1">Active</option>
				 <option value="0">Inactive</option>
			 </select>
             <label>Content</label>
					 <textarea name="content" id="content" class="txtarea"><?=$rr['content']?></textarea>
                </div>
		   <div id="bottomform">
			<input type="submit" value="Save" name="submitform" class="submitform" />
			</div>
		  </form>
<?php
	}
?>