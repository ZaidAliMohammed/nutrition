<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$password=md5($_POST['password']);
$conf_pass=md5($_POST['conf_pass']);
if($password =='' or $conf_pass=='' or $password!=$conf_pass){
	echo '<div class="error">Please check the data</div>';
	}else{	
  $q6 = mysql_query("UPDATE aro_members SET password='$password' where id='$id'"); 
  echo '<div class="success">Content was edited successfully</div>';
  echo $id;

 }
}
?>
<script type="text/javascript">
    parent.$.fancybox.close();
</script>