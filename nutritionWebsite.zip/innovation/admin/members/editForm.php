<script type="text/javascript" src="../assets/js/jquery-1.8.3.min.js"></script>
<script type='text/javascript' src='../assets/js/jquery.form.js'></script>

 <script type="text/javascript">
	$(document).ready(function() { 
	$("#DataForm").ajaxForm({ 
        target: '#preview', 
        success: function(response) { 
            	$('#preview').fadeIn();
				setTimeout(function(){},3000)
        }
    });
});
	</script>

<?php
include('../../db/db.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
}
else
$id="";

	?>
    <style type="text/css">
	.inptext{
		width:200px;
		height:25px;
	}
	label{
		width:200px;
		margin-top:100px;
	}
	.for{
		margin-bottom:25px;
	}
	.submitform{
		border:none;
		cursor:pointer;
		background:none;
		font-size:14pt;
	}
	#bottomform{
		text-align:center;
	}
	</style>
	<div id="preview"></div>
	<form action="edit-data.php" method="post"  name="DataForm" id="DataForm"  enctype="multipart/form-data" >
	       <input type="hidden" name="id" id="id" value="<?php echo $id?>" class="inptext" />
		   <div id="leftform">
           <div class="for">
		   	<div><label>Password</label></div>
			<div> <input type="text" name="password" id="password" value="" class="inptext" /></div>
             </div>
             <div class="for">
			<div><label>Confirm Password</label></div>
			 <input type="text" name="conf_pass" id="conf_pass" value="" class="inptext" />
             </div>
		   </div>
		   <div id="bottomform">
			<input type="submit" value="Save" name="submitform" class="submitform" />
			</div>
		  </form>