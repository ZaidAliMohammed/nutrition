
<div id="main-content">
   <div id="indicator"><strong>Logged in as : <?php echo $fgmembersite->UserFullName(); ?></strong>  </div>
 <div id="left-menu">
	   <?php include('includes/leftmenu.php'); ?>
 </div>
 <div id="pagecontent">
  <div>
  <?php include('../db/db.php');
   $q=mysql_query("select * from aro_members order by id ASC");
   ?>
   <form method='post' action='members/pages-delete.php' name="deleteForm" id="deleteForm">
     <div class="demo_jui" style="float:left; background:#fff; padding-top:15px;">
           <table cellpadding="0" cellspacing="0" border="0" class="table-list display" id="listcontent">               
                <thead>
                    <tr valign="top">
                        <th align="left">ID</th>
						<th align="left">Name</th>
                        <th align="left">Last N</th>
                        <th align="left">Email</th>
                       
                         <th align="center">Mobile</th>
                          <th align="center">Country</th>
       
                          <th align="center">City</th>
                          <th align="center">Wholesale Orders</th>
                          <th align="center">Wholesale Cart</th>
                          <th align="center">Retail Orders</th>
						<th align="center">Status</th>
                        <?php if(($_SESSION['control_of_user'])!='User'){ ?>
                        <th>Delete <input id="CheckAll" onclick="checkAll();" name="CheckAll" type="checkbox" /></th>
                        <?php } ?>
                    </tr>
                </thead>
				<tbody>
					<?php while($r=mysql_fetch_array($q)){ ?>
					 <tr id="<?=$r['id'];?>">
					   <td><?=$r['id'];?></td>
					   <td class="pointertd"><a style="text-decoration:none;color:#000; font-size:12pt; font-weight:bold;" class="various fancybox.iframe" href='members/editForm.php?id=<?=$r['id']?>'><?=$r['fname']?></a></td>
                       <td class=""><?=$r['lname']?></td>
					   <td class="mail"><?=$r['email'];?></td>
					   
                        <td><?=$r['mobile'];?></td>
                        <td><?=$r['country']?></td>
                         
                          <td><?=$r['address']?></td>
                      <td><a href="whole_orders.php?id=<?=$r['id'];?>">Orders</a></td>
                      <td><a href="whole_cart.php?id=<?=$r['id'];?>">Carts</a></td>
                      <td><a href="orders.php?id=<?=$r['id'];?>">Orders</a></td>
                      
                       <td class="clickable" id="status<?=$r['id'];?>" onclick="changeStatus('members/status.php?id=<?=$r['id'];?>',<?=$r['id'];?>)">
					    <?php if($r['status']==1){?><img src="assets/icons/tick.png" /><?php }else{ ?><img src="assets/icons/cross.png" /><?php } ?>
					   </td>
					   <td align="center"><input type='checkbox' name='checkbox[]' id='checkbox[]' value="<?php echo $r['id'];?>" style="width:50px;" /></td>
					  </tr>
					<?php } ?>
	             </tbody>
             </table>
			 </div>
              <input id='delete' type='submit' class='button' name='delete' value='Delete Selected Items' style="width:150px;"  onclick="return confirm('Do you wish to Delete Items?')"/>
	</form>
	</div>
 </div>
</div>