<?php
include_once '../../db/db.php';
if(isset($_POST['id'])) { 
$id = intval($_POST['id']); 
if($id <= 0) { 
die('The ID is invalid!'); 
} 
else {						
$q31 = mysql_query("SELECT * FROM splendor_video WHERE `id`='$id'");
$r31=mysql_fetch_array($q31);
	
if($r31['title']=='0'){
	$q41 = mysql_query("UPDATE splendor_video SET `title`='0' WHERE `id`='$id'");
	echo '<img src="assets/icons/cross.png" />';}
	
else if ($r31['title']=='1')
{$q51 = mysql_query("UPDATE splendor_video SET `title`='1' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	

else if($r31['title']=='2')
{$q61 = mysql_query("UPDATE splendor_video SET `title`='2' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';	
}

else if($r31['title']=='3')
{$q71 = mysql_query("UPDATE splendor_video SET `title`='3' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';	
}

else
{$q81 = mysql_query("UPDATE splendor_video SET `title`='4' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';	
}


}
}
?>