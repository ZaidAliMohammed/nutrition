<?php
include('../../db/db.php');
include ('../includes/thumb.php');
include '../secureInput.php';
if (isset ($_POST['submitform'])) {
	$title=secureInput($_POST['title']);
	$link=secureInput($_POST['link']);
	$status=secureInput($_POST['status']);
	

		$q6=mysql_query("insert into  splendor_video (title,status,link) values('$title','$status','$link')") or die(mysql_error());
		echo'<div class="success">Content was added successfully.</div>';
				}
	
	
	
 
?>