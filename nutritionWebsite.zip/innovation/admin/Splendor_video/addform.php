	<div id="preview"></div>
	<form action="Splendor_video/add-slider.php" method="post"  name="AddNew" id="AddNew"  enctype="multipart/form-data" >
				   <div id="leftform">
	            <div id="preview"></div>
					
                    
                     <label>Title</label>
					 <select name="title" class="inpselect">
                             <option value="">Select Title</option>
                             <option value="0">Main Video</option>
                             <option value="1">Video 1</option>
							 <option value="2">Video 2</option>
							 <option value="3">Video 3</option>
							 <option value="4">Video 4</option>
                         </select>
					  
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="">Select Status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
                      
                         
						 
						 
    

				   <div id="bottomform">
					
				<input type="submit" value="Add" name="submitform" class="submitform" />
                <input type="reset" value="reset" id="reset" />
				   </div>
			</form>
