<div id="header">
    <div id="header-login"><a href="../home" target="_new">view website</a><a href="logout.php">Logout</a></div>
	<div id="header-content">
		 <div id="header-logo">
			 <img src="assets/images/be_header/header_logo.png" />
		</div>
        <div class="header_right date_h"><?=date('D d M Y');?></div>
	</div>
	<div id="header-border"></div>
</div>