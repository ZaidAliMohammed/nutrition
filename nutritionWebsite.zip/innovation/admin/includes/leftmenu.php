<STYLE>
#accordion {
	list-style: none;
}
#accordion li{
	display: block;
	font-weight: bold;
	cursor: pointer;
	list-style: circle;
}
#accordion ul {
	list-style: none;
	padding: 0 0 0 0;
	display: none;
	width:100%;
}
#accordion ul li{
	font-weight: normal;
	cursor: auto;
	padding-left:10%;
	width:90%;
	background:#ddd;
}
#accordion a {
	text-decoration: none;
}
#accordion a:hover {
	text-decoration: underline;
}
</STYLE>
<div class="bcl">&nbsp;</div>
<ul id="accordion" class="menuleft" style="margin:0; padding:0;">
		  <li class="menuleft_b">Categories</li>
		  <li class="menuleft_a" id="home"><a href="home.php">Home</a></li>
		  <li class="menuleft_a" id="About"><a href="about.php">About us</a></li>
          <li class="menuleft_a" id="Panera"><a href="Panera.php">Banner</a></li>
		  <li class="menuleft_a" id="Innovation_menu"><a href="Innovation_menu.php">Innovation-menu</a></li>
		  <li class="menuleft_a" id="Innovation_hotdeal"><a href="Innovation_hotdeal.php">Innovation-hotdeal</a></li>
		  <li class="menuleft_a" id="Innovation_flipbook"><a href="Innovation_flipbook.php">Innovation-flipbook</a></li>
		  <li class="menuleft_a" id="Innovation_imageslider"><a href="Innovation_imageslider.php">Innovation-imageslider</a></li>
		  <li class="menuleft_a" id="Splendor_video"><a href="Splendor_video.php">Splendor-video</a></li>
          <li class="menuleft_a" id="users"><a href="users.php">User Manager</a></li>
	</ul>
</ul>
<SCRIPT>
var page='<?=$_SESSION['admin']?>';
$(".menuleft_a").css({'background':'none'});
if(page=='city'){
	$("#country").css({'background':'#fff'});
}else if(page=='details'){
	$("#packages").css({'background':'#fff'});
}
else{
$("#"+page).css({'background':'#fff'});
}

</SCRIPT>