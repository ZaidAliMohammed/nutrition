<?php
require_once('../../db/db.php');
if($_POST['id'])
	{
		$id=$_POST['id'];
		$query = "SELECT * FROM `innovation_flipbook` WHERE `id`='$id'";
		$result = mysql_query($query);
		while($row = mysql_fetch_array($result)) {
		$fileToRemove = '../../turnjs4/samples/magazine/pages/'.$row['image'];
		if (file_exists($fileToRemove)) {
   			// yes the file does exist
   			unlink($fileToRemove);
			}
		$fileToRemove = '../../turnjs4/samples/magazine/pages/'.$row['image'];
		if (file_exists($fileToRemove)) {
   		// yes the file does exist
   		unlink($fileToRemove);
		}
		$qd=mysql_query("UPDATE `innovation_flipbook` set image='' where id='$id'")or die(mysql_error());
		}
		
}
?>