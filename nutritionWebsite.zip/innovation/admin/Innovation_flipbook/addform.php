	<div id="preview"></div>
	<form action="Innovation_flipbook/add-slider.php" method="post"  name="AddNew" id="AddNew"  enctype="multipart/form-data" >
				   <div id="leftform">
	            <div id="preview"></div>
					
                    
                     <label>Title</label>
					 <select name="title" class="inpselect">
                     <option value="">Select Title</option>
					 <option value="1">Page 1</option>
                     <option value="2">page 2</option>
					 <option value="3">Page 3</option>
                     <option value="4">page 4</option>
					 <option value="5">Page 5</option>
                     <option value="6">page 6</option>
					 <option value="7">Page 7</option>
                     <option value="8">page 8</option>
					 <option value="9">Page 9</option>
                     <option value="10">page 10</option>
					 <option value="11">page 11</option>
                     <option value="12">Page 12</option>
                     </select>
					  
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="">Select Status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
                      
                         
						 
						 
                         <label>Image</label>
                     <br />
                     <label>Dear User the pictures is less to 800 pixles</label>
					 <input type="text" name="image" id="img_link" disabled="disabled" value="" class="inptext" />
                     <label for="file" id="bro">Browse</label>
                     <input type="file" name="file" onchange="change_image(this.id)" id="file" style="display:none" />
				   </div>
				   <div id="bottomform">
					
				<input type="submit" value="Add" name="submitform" class="submitform" />
                <input type="reset" value="reset" id="reset" />
				   </div>
			</form>
