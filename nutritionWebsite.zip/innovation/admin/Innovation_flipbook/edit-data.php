<?php
include('../../db/db.php');
include_once('../secureInput.php');
if(isset($_POST['id'])) {
$id = intval($_POST['id']);
$title=secureInput($_POST['title']);
$main=($_POST['title']);
$status=secureInput($_POST['status']);

if($main ==''){
	echo '<div class="error">Please insert title</div>';
	exit;
	}else{
		
		$qq=mysql_query("UPDATE `innovation_flipbook` set title='$main' where id='$id'") or die (mysql_error());
  echo '<div class="success">Content was edited successfully</div>';


	}
}
?>