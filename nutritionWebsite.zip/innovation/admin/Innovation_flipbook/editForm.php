<?php
include('../../db/db.php');
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$qq=mysql_query("select * from   innovation_flipbook where id='$id'");
	$rr=mysql_fetch_array($qq);
	?>
	<div id="preview"></div>
	<form action="Innovation_flipbook/edit-data.php" method="post"  name="DataForm" id="DataForm"  enctype="multipart/form-data" >
	       <input type="hidden" name="id" id="id" value="<?=$rr['id']?>" class="inptext" />
		   <div id="leftform">
					 
					  <label>title</label>
					  					 <select name="title" class="inpselect">
                     <option value="<?=$rr['title']?>">Select Title</option>
					 <option value="1">Page 1</option>
                     <option value="2">page 2</option>
					 <option value="3">Page 3</option>
                     <option value="4">page 4</option>
					 <option value="5">Page 5</option>
                     <option value="6">page 6</option>
					 <option value="7">Page 7</option>
                     <option value="8">page 8</option>
					 <option value="9">Page 9</option>
                     <option value="10">page 10</option>
					 <option value="11">page 11</option>
                     <option value="12">Page 12</option>
                     </select>
					
                      <label>Status</label>
                        <select name="status" class="inpselect">
                             <option value="<?=$rr['status']?>">Select Status</option>
                             <option value="1">Active</option>
                             <option value="0">Inactive</option>
                         </select>
						 
		   </div>
		   <div id="bottomform">
			<input type="submit" value="Save" name="submitform" class="submitform" />
			</div>
		  </form>
<?php
	}
?>