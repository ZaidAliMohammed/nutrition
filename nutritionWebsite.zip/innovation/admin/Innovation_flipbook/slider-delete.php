<?php
require_once('../../db/db.php');
if($_POST['delete'])
	{
		$checkbox = $_POST['checkbox'];
		$countCheck = count($_POST['checkbox']);
		for($i=0;$i<$countCheck;$i++)
		{               $del_id  = $checkbox[$i];
			            $query = "SELECT * FROM  innovation_flipbook WHERE `id`={$del_id}";
						$result = mysql_query($query);
						
						while($row = mysql_fetch_array($result)) {
								$fileToRemove = '../../turnjs4/samples/magazine/pages/'.$row['image'];
								if (file_exists($fileToRemove)) {
   													// yes the file does exist
   													unlink($fileToRemove);
								}
								$fileToRemove = '../../turnjs4/samples/magazine/pages/'.$row['image'];
								if (file_exists($fileToRemove)) {
   													// yes the file does exist
   													unlink($fileToRemove);
								}
						}

			$q1 = mysql_query("DELETE FROM `innovation_flipbook` WHERE id = '$del_id'");
			
		}
		header("Location: ../Innovation_flipbook.php");
	}
?>