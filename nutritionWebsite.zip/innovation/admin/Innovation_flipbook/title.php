<?php
include_once '../../db/db.php';
if(isset($_POST['id'])) { 
$id = intval($_POST['id']); 
if($id <= 0) { 
die('The ID is invalid!'); 
} 
else {						
$q31 = mysql_query("SELECT * FROM innovation_flipbook WHERE `id`='$id'");
$r31=mysql_fetch_array($q31);
	
if($r31['status']=='1'){
	$q41 = mysql_query("UPDATE innovation_flipbook SET `title`='1' WHERE `id`='$id'");
	echo '<img src="assets/icons/cross.png" />';}
	
else if ($r31['title']=='2')
{$q51 = mysql_query("UPDATE innovation_flipbook SET `title`='2' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	

else if ($r31['title']=='3')
{$q61 = mysql_query("UPDATE innovation_flipbook SET `title`='3' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='4')
{$q71 = mysql_query("UPDATE innovation_flipbook SET `title`='4' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='5')
{$q81 = mysql_query("UPDATE innovation_flipbook SET `title`='5' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='6')
{$q91 = mysql_query("UPDATE innovation_flipbook SET `title`='6' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='7')
{$q101 = mysql_query("UPDATE innovation_flipbook SET `title`='7' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='8')
{$q111 = mysql_query("UPDATE innovation_flipbook SET `title`='8' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='9')
{$q121 = mysql_query("UPDATE innovation_flipbook SET `title`='9' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	
	else if ($r31['title']=='10')
{$q131 = mysql_query("UPDATE innovation_flipbook SET `title`='10' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}	
	else if ($r31['title']=='11')
{$q131 = mysql_query("UPDATE innovation_flipbook SET `title`='10' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';}
else
{$q141 = mysql_query("UPDATE innovation_flipbook SET `title`='11' WHERE `id`='$id'");
	echo '<img src="assets/icons/tick.png" />';	
}

}
}
?>