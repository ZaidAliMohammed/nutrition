

$(document).ready(function() { 
	 $('#add_request_newsp').click(function() {
		 	var titleVal = $("#title").val(); 
			var pageVal = $("#page").val();
			var imageVal = $("#image").val();
			var categoryVal = $("#category").val();
			if(titleVal == '') {
				
				$("#title_error").html('');
				$("#title1").after('<div class="error" id="title_error">Please insert title</div>');
				return false
			}
			else
			{
				$("#title_error").html('');
			}
			
			if(pageVal == '') {
				$("#page_error").html('');
				$("#page1").after('<div class="error" id="page_error">Please insert page</div>');
				return false
			}
			else
			{
				$("#page_error").html('');
			}
			if(imageVal == '') {
				$("#image_error").html('');
				$("#image1").after('<div class="error" id="image_error">Please insert image</div>');
				return false
			}
			else
			{
				$("#image_error").html('');
			}
			if(categoryVal == '') {
				$("#category_error").html('');
				$("#category1").after('<div class="error" id="category_error">Please insert category</div>');
				return false
			}
			else
			{
				$("#category_error").html('');
			}
	 });
});