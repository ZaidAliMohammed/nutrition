function getXMLHTTP() { //fuction to return the xml http object
		var xmlhttp=false;	
		try{
			xmlhttp=new XMLHttpRequest();
		}
		catch(e)	{		
			try{			
				xmlhttp= new ActiveXObject("Microsoft.XMLHTTP");
			}
			catch(e){
				try{
				xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
				}
				catch(e1){
					xmlhttp=false;
				}
			}
		}
		 	
		return xmlhttp;
	}
function backpage(){
	if (document.referrer != "") {
	window.history.go(-1);
	}
}
function AddNew(strURL,page) {
	/**
		var req = getXMLHTTP();
		if (req) {
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {
						document.getElementById('contentAjax').innerHTML=req.responseText;	
						
							$(document).ready(function() { 
								$('#AddNew').ajaxForm({ 
									target: '#preview', 
									success: function(response) { 
											$('#preview').fadeIn();
											
									}
								});
								
							});
							
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}	
				}
				$('.date').datepick();
				CKEDITOR.replaceAll();			
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}
		**/
		$.post(strURL,function(re){
			$("#contentAjax").html(re);
			CKEDITOR.replaceAll();
			$('#AddNew').ajaxForm({ 
						target: '#preview', 
						success: function(response) { 
						if(response=='1')
						{
						$("#preview").html('<div class="success">Content was added successfully.</div>');
						}else{
						$("#preview").html(response);
						}
						$('#preview').fadeIn();
						setTimeout(function(){$.post(page+"/table.php",function(re){
									$("#content_table").html(re);
									
									$('#preview').fadeOut();
									$("#reset").click();
									})},2000);
						}
				});
			});	
	}
function deleteimage(a,page){
	var conf=confirm("do you remove this pictures");
	if(conf){
	$.post(page+"/deleteimages.php",{'id':a},function(re){
		$.post(page+"/table.php",function(r){location.reload()});
	});
	}
}
function table_style(){
	$('#listcontent').dataTable( {"aoColumnDefs": [{ 'bSortable': false, 'aTargets': [ 3 ] } ]});
}
function getEdit(strURL,hrefid, page) {		
		$("tr").removeClass('ActiveItem');
	     $("#"+hrefid).toggleClass('ActiveItem');
		var req = getXMLHTTP();
		if (req) {
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {
						document.getElementById('contentAjax').innerHTML=req.responseText;	
							$(document).ready(function() { 
								$('#DataForm').ajaxForm({ 
									target: '#preview', 
									success: function(response) { 
									if(response=='1')
									{
									$("#preview").html('<div class="success">Content was added successfully.</div>');
									}else{
									$("#preview").html(response);
									}
									$('#preview').fadeIn();
									setTimeout(function(){$.post(
									page+"/table.php",
									function(re){
									$("#content_table").html(re);
									$('#preview').fadeOut();
									$("#reset").click();
									})},2000);
									
									}
								});
							});					
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}
		CKEDITOR.replaceAll();
		$('.date').datepick({
			dateFormat: 'dd/MM/yyyy',
			minDate:0,
			});				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}
		
				
	}
function getSubCategory(strURL) {		
		alert(strURL);
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {
						document.getElementById('material-ajax-2').innerHTML=req.responseText;						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}	
				}
				CKEDITOR.replaceAll();
				$('.date').datepick({
			dateFormat: 'dd/MM/yyyy',
			minDate:0,
			});			
			}
						
			req.open("GET", strURL, true);
			req.send(null);
		}
				
	}
function getCategory(strURL) {		
		
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {
						document.getElementById('material-ajax').innerHTML=req.responseText;						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}
				
	}
function GetTypeOutdoorMedia(strURL) {		
		
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {
						document.getElementById('inpt-ajax').innerHTML=req.responseText;						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}
				
	}
function changeStatus(strURL,id) {
	
	$.post(strURL,{'id':id},function(re){
			$('#status'+id).html(re);
	});				
}
function changeselling(strURL,id) {
		 var result = confirm("Want to Change selling?");
		 if (result) {
	$.post(strURL,{'id':id},function(re){
			$('#selling'+id).html(re);
	});	
		 }
}
function changerelease(strURL,id) {
		 var result = confirm("Want to Change release?");
		 if (result) {
	$.post(strURL,{'id':id},function(re){
			$('#release'+id).html(re);
	});	
		 }
}
function changesoon(strURL,id) {
		 var result = confirm("Want to Change Coming Soon?");
		 if (result) {
	$.post(strURL,{'id':id},function(re){
			$('#soon'+id).html(re);
	});	
		 }
}
function changehot(strURL,id) {
		 var result = confirm("Want to Change Hot Deal?");
		 if (result) {
	$.post(strURL,{'id':id},function(re){
			$('#hot'+id).html(re);
	});	
		 }
}
function changenew(strURL,id) {
	$.post(strURL,{'id':id},function(re){
			$('#type'+id).html(re);
	});				
}
function changeNews(strURL,id) {
	$.post(strURL,{'id':id},function(re){
			$('#news'+id).html(re);
	});				
}
	function changeType(strURL,id) {		
		
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {
						document.getElementById('type'+id).innerHTML=req.responseText;						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}
				
	}
	function changeOffer(strURL,id) {		
		
		var req = getXMLHTTP();
		
		if (req) {
			
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {
						document.getElementById('new'+id).innerHTML=req.responseText;						
					} else {
						alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}
				
	}
	function change_image(a){
		$("#img_link").val($("#"+a).val())
	}
$(document).ready(function(){
table_style();

CKEDITOR.config.height = 80;
			CKEDITOR.config.toolbar = [
		   ['Styles','Font','FontSize','Bold','Italic','Underline','StrikeThrough','Find','Replace','NumberedList','BulletedList'],
		   ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
		   ['Image','Table','Link','Smiley','TextColor','BGColor','Source']
		] ;
		CKEDITOR.replaceAll();
		$('.date').datepick({
			dateFormat: 'dd/MM/yyyy',
			minDate:0,
			});
		
});
function country_change(a){
	var id=$("#"+a).val();
	$.post("hotels/city.php",{'id':id},function(re){
		$("#city_hotels").html(re);
	});
}
function newform(){
	$("#add_new").fadeIn(0);
	$("#edit_new").fadeOut(0);
	$("#deleteForm").fadeOut(0);
	$("#addform").fadeOut(0);
	$("#closeform").fadeIn(0);
	$("#add_new").animate({'height':'120%'},500);
}
function close_add(){
	$("#add_new").fadeOut(0);
	$("#edit_new").fadeOut(0);
	$("#add_new").css({'height':'0px'});
	$("#deleteForm").fadeIn(0);
	$("#addform").fadeIn(0);
	$("#closeform").fadeOut(0);
}
function edit_new(a,b,page){
	$.post(a,{'id':b},function(re){
	$("#deleteForm").fadeOut(0);
	$("#add_new").fadeOut(0);
	$("#edit_new").fadeIn(0);
	$("#addform").fadeOut(0);
	$("#closeform").fadeIn(0);
	$("#edit_new").html(re);	
	$("#edit_new").animate({'height':'120%'},500);
	});
}