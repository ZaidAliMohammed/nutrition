


<?php
include 'securimage.php';
$captcha = new Securimage;


if($captcha->check($_POST['code'])==false){echo 0;}
else{echo 1;}
?>